<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Document</title>
    <script src="Screen/button.js"></script>
    <script src="Screen/full.js"></script>
    <style>
        html,
        body {
            margin: 0;
            padding: 0;
            background-color: #333;
            color: #fff;
        }
        .nav{
            justify-content: space-around;
            height: auto;
            display: flex;
            justify-content: space-around;
            align-items: center;
            box-shadow: 0px 0px 10px 2px rgba(0, 0, 0, 0.2);
        }
        .nav .ul{
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
            border: 0;
        }
        .ul {
            
            list-style-type: none;
        }
        .li {
            margin-top: 10px;
            list-style: none;
            display: inline-block;
        }
        a {
            text-decoration: none;
        }
        .button, a, .full {
            background: none!important;
            border: none;
            padding: 8px!important;
            font-family: arial!important;
            display: block;
            color: white;
            font-size: 18px;
            cursor: pointer;
            color: white;
            position: relative;
            text-decoration: none;
        }

        a::before, .button::before, .full::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 4px;
            border-radius: 4px;
            background-color: white;
            bottom: 0;
            left: 0;
            transform-origin: right;
            transform: scaleX(0);
            transition: transform .3s ease-in-out;
        }

        a:hover::before, .button:hover::before {
            transform-origin: left;
            transform: scaleX(1);
        }
        
        footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            color: white;
        }
        .style {
            padding-right: 5px;
            padding-top: 5px;
            float: right;
        }
    </style>
</head>
<body>
    <?php
    session_start();
    require 'functions.php';
    if (!isUserLoggedIn()) {
        header('Location:login.php');
        die;
    }
    require 'connection.php';
    ?>
   
    <!--<h1 class="cover-heading">Manager</h1>-->
        <header>
            <!--<h3 class="masthead-brand">MY SECRET DIARY</h3>-->
            
                <?php if (isUserLoggedIn()) { ?>
                <nav class="nav">
                    <ul class="ul">
                        <li><a class="li" style="color:white" href="#" onclick="Fullscreen();">Home</a></li>
                        <li class="li" class="nav-masthead">
                            <form action="logout.php" method="POST">
                                <input type="hidden" name="logout" value="1">
                                <button class="button" style="--c: #373B44;--b: 5px;--s:12px" class="">Logout</button>
                            </form>
                        </li>
                    </ul>
                </nav>
                <?php } ?>
            
        </header>
    <main>
        <?php
        if (!empty($_SESSION['message'])) { ?>
        <script>
            window.alert('<?= $_SESSION['message'] ?>');
        </script>
        <?php
            $_SESSION['message'] = '';
        }
        ?>

        <?php if (getUserEmail() == "Capo") { ?>

        
        <?php } ?>
    </main>
    <footer>
        
        <!--closeFullscreen-->
        <div class="style">
            <button class="full" onclick="Screen();">
                <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="black" class="bi bi-aspect-ratio-fill" viewBox="0 0 16 16">
                    <path d="M0 12.5v-9A1.5 1.5 0 0 1 1.5 2h13A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 12.5M2.5 4a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 1 0V5h2.5a.5.5 0 0 0 0-1zm11 8a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-1 0V11h-2.5a.5.5 0 0 0 0 1z"/>
                </svg>
            </button>
        </div>
    </footer>   
</body>
</html>


<!--<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
        <header class="masthead mb-auto">
            <div class="inner">
                <h3 class="masthead-brand">MY SECRET DIARY</h3>
                <nav class="nav nav-masthead justify-content-center">
                    <a class="nav-link <?= strpos($page, 'index.php') !== false ? 'active' : '' ?>" href="index.php">Home</a>
                    <?php if (!isUserLoggedIn()) { ?>
                        <a class="nav-link  <?= strpos($page, 'signedup.php') !== false ? 'active' : '' ?>" href="signedup.php">SIGNUP</a>
                        <a class="nav-link  <?= strpos($page, 'login.php') !== false ? 'active' : '' ?>" href="login.php">LOGIN</a>

                    <?php } else { ?>
                        <ul class="nav">
                            <li class="nav-item px-4">
                                <form action="logout.php" method="POST">
                                    <input type="hidden" name="logout" value="1">
                                    <button class="btn btn-default nav-link">LOGOUT</button>
                                </form>
                            </li>
                        </ul>
                    <?php } ?>
                </nav>
            </div>
        </header>