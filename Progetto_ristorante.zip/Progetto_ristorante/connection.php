<?php
    /*Connessione*/
    $server_name = "localhost";
    $user = "root";
    $password = "";
    $dbname = "ristorante_db";

    $conn = new mysqli($server_name, $user, $password, $dbname);

    if($conn->connect_error){
        die("Connection error".$conn->connect_error);
    }

?>
