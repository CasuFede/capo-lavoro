<?php
session_start();
require 'connection.php';

// Verifica se il metodo di richiesta è POST e se ci sono dati inviati
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['email']) && !empty($_POST['password'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Preparazione della query SQL per selezionare l'utente dal database
    $sql = 'SELECT id, username, password FROM account WHERE username=?';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $email);
    
    // Esecuzione della query
    if ($stmt->execute()) {
        // Ottenimento dei risultati della query
        $result = $stmt->get_result();

        // Verifica se è stato trovato un utente con l'username fornito
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            // Verifica se la password fornita corrisponde alla password memorizzata nel database
            if (password_verify($password, $row['password'])) {
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_email'] = $row['username'];

                // Reindirizzamento in base al tipo di utente
                if ($email == "Capo") {
                    header("Location: Dashboard/index.php");
                    exit;
                } else {
                    // Salvataggio dell'ID della sessione nel database
                    $session_id = session_id();
                    $cameriere_id = $_SESSION['user_id'];
                    $dataOra = date("Y-m-d H:i:s");
                    $query = "INSERT INTO sessions (session_id, cameriere_id, last_activity) VALUES ('$session_id', '$cameriere_id', '$dataOra')";
                    $result = mysqli_query($conn, $query);
                    header("Location: Dashboard/ordinazioni/invio.php");
                    exit;
                }
            } else {
                $_SESSION['errors'] = 'Password errata';
            }
        } else {
            $_SESSION['errors'] = 'Username inesistente';
        }
    } else {
        $_SESSION['errors'] = 'Errore nel recupero dei dati';
    }

    // Chiudi la query
    $stmt->close();
} else {
    $_SESSION['errors'] = 'Inserire username e password';
}

// Reindirizzamento alla pagina di login in caso di errore o se i dati non sono stati inviati
header('Location: login.php');
exit;
?>

