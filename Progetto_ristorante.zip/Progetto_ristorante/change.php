<?php
/*Connessione*/
/*$server_name = "localhost";
$user = "root";
$password = "";
$dbname = "ristorante_db";

$conn = new mysqli($server_name, $user, $password, $dbname);

if($conn->connect_error){
    die("Connection error".$conn->connect_error);
}


$password = '';
$hash = password_hash($password, PASSWORD_DEFAULT);
$sql = "UPDATE account SET password = '$hash' WHERE id = 4";

// Esecuzione della query
if ($conn->query($sql) === TRUE) {
    echo "Dato aggiornato con successo";
} else {
    echo "Errore durante l'aggiornamento del dato: " . $conn->error;
}
$conn->close();*/
?>