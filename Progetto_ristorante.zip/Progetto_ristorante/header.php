<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Cover Template · Bootstrap v4.6</title>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    
    <link rel="stylesheet" href="style.css">


    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>
</head>
 <!--center to left-->
<body class="text-center">
    <?php
    $page = $_SERVER['SCRIPT_NAME'];
    ?>
    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
        <!--mb-auto to mb-->
        <header class="masthead mb-auto">
            <div class="inner">
                <!--<h3 class="masthead-brand">MY SECRET DIARY</h3>-->
                <nav class="nav nav-masthead justify-content-center">
                    <?php if (isUserLoggedIn()) { ?>
                        <a class="nav-link <?= strpos($page, 'index.php') !== false ? 'active' : '' ?>" href="index.php">Home</a>
                        <ul class="nav">
                            <li class="nav-item px-3">
                                <form action="logout.php" method="POST">
                                    <input type="hidden" name="logout" value="1">
                                    <button class="btn btn-default nav-link">LOGOUT</button>
                                </form>
                            </li>
                        </ul>
                    <?php } ?>
                </nav>
            </div>
        </header>
        <!--inner cover to inner-->
        <main role="main" class="inner">