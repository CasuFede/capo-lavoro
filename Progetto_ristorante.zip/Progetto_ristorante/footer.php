</main>

<footer class="mastfoot mt-auto">
    <div class="inner">
        <p><a href="https://getbootstrap.com/"></a><a href="https://twitter.com/mdo"></a></p>
    </div>
</footer>
</div>


<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</body>

</html>

