<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>  
<!DOCTYPE html>
<html>
    <head>
        <title>Ricezione dati</title>
        <meta charset="UTF-8" />
    </head>
    <body>
        
        <h1>Ricezione dati</h1>
        <?php
        $p2 = true;
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            if (empty($_POST["data"])) {
                $p2 = false;
            } else {
                $data = mysqli_real_escape_string($conn, $_POST["data"]);
            }
            if (empty($_POST["ora"])) {
                $p2 = false;
            } else {
                $ora = mysqli_real_escape_string($conn, $_POST["ora"]);
            }
            if (empty($_POST["minuti"])) {
                $p2 = false;
            } else {
                $minuti = mysqli_real_escape_string($conn, $_POST["minuti"]);
            }

            $time = $ora . ":" . $minuti . ":" . "00";
            $datatime = $data . " " . $time;
            
            if (empty($_POST["nome"])) {
                $p2 = false;
            } else {
                $nome = mysqli_real_escape_string($conn, $_POST["nome"]);
            }
            if (empty($_POST["cognome"])) {
                $p2 = false;
            } else {
                $cognome = mysqli_real_escape_string($conn, $_POST["cognome"]);
            }
            if (empty($_POST["coperti"])) {
                $p2 = false;
                echo $_POST["coperti"];
            } else {
                $coperti = mysqli_real_escape_string($conn, $_POST["coperti"]);
            }
            if (empty($_POST["note"])) {
                
                $note = "";
            } else {
                $note = mysqli_real_escape_string($conn, $_POST["note"]);
            }
            if (empty($_POST["telefono"])) {
                
                $p2 = false;
            } else {
                $telefono = $_POST["telefono"];

            }
            // Controlla se è stato caricato un file senza errori
            echo $datatime;
            if ($p2 != false) { 
                $query = "INSERT INTO prenotazioni (nome, cognome, datetime, coperti, telefono, note)
                VALUES('$nome', '$cognome', '$datatime', '$coperti', '$telefono', '$note')";
                if($conn->query($query) === TRUE){
                    header('Location:tabella.php');
                    $_SESSION['risp'] = "Prenotazione inserita con successo";
                    die();
                }else{
                    echo "Inserimento errore".$conn->error;
                }
            } else {
                
                $_SESSION['risp'] = 'Errore nel inserimento dati';
                header('Location:tabella.php');
                die();
            }
            
        } else {
            $_SESSION['risp'] = 'ERRORE';
            header('Location:tabella.php');
            die();
        }
        ?>
        <?php include "../close_connection.php"; ?>
    </body>
</html>