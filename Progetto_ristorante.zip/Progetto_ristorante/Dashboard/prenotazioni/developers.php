<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>

<?php

$db= $conn;
$tableName="prenotazioni";
if(isset($_GET['edit'])){
$id = validate($_GET['edit']);
$condition= ['id' =>$id];
$columns = ['id', 'nome','cognome','datetime', 'coperti', 'note', 'telefono'];
$editData = edit_data($db, $tableName, $columns, $condition);
}
function edit_data($db, $tableName, $columns, $condition){
if(empty($db)){
 $msg= "Database connection error";
}elseif (empty($columns) || !is_array($columns)) {
  $msg="columns Name must be defined in an indexed array";
}elseif (!is_array($condition)) {
  $msg= "Condition data must be an associative array";
}
elseif(empty($tableName)){
  $msg= "Table Name is empty";
}else{
$columnName = implode(", ", $columns);
    $conditionData='';
    $i=0;
    foreach($condition as $index => $data){
        $and = ($i > 0)?' AND ':'';
         $conditionData .= $and.$index." = "."'".$data."'";
         $i++;
    }
$query = "SELECT ".$columnName." FROM $tableName";
$query .= " WHERE ".$conditionData;
$result = $db->query($query);
$row= $result->fetch_assoc();
return $row;
if($row== true){
  
 if ($result->num_rows > 0) {
    $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    $msg= $row;
    
 } else {
    $msg= "No Data Found";
  
 }
}else{
  $msg= mysqli_error($db);
}
}
return $msg;
}
// update data
extract($_POST);
if(isset($update) && isset($_GET['edit'])){
    $columns = ['id', 'nome','cognome','datetime', 'coperti', 'telefono', 'note'];
$updateDate = date("Y-m-d H:i:s");
$inputData = [
'nome' => validate($nome) ?? "",
'cognome'   => validate($cognome) ?? "",
'datetime'   => validate($datetime) ?? "",
'coperti'   => validate($coperti) ?? "",
'telefono'   => validate($telefono) ?? "",
'note'   => validate($note) ?? "",
'created_at' => $updateDate ?? ""
];
$id = validate($_GET['edit']);
$condition= ['id' =>$id];
$result= update_data($db, $tableName, $inputData, $condition);
header("location:form.php");
}
function update_data($db, $tableName, $inputData, $condition){
 $data = implode(" ",$inputData);
if(empty($db)){
 $msg= "Database connection error";
}elseif(empty($tableName)){
  $msg= "Table Name is empty";
}elseif(trim( $data ) == ""){
  $msg= "Empty Data not allowed to update";
}elseif(!is_array($inputData) && !is_array($condition)){
  $msg= "Input data & condition must be in array"; 
}else{
// dynamic column & input value
    $cv=0;
    $columnsAndValue='';
    foreach ($inputData as $index => $data) {
      $comma= ($cv>0)?', ':'';
      $columnsAndValue .= $comma.$index." = "."'".$data."'";
    $cv++;
    }
   
// dynamic condition       
    $conditionData='';
    $c=0;
    foreach($condition as $index => $data){
        $and = ($c>0)?', ':'';
        $conditionData .= $and.$index." = "."'".$data."'";
        $c++;
    }
// update query        
    $query   =  "UPDATE ".$tableName;
    $query  .= " SET ".$columnsAndValue;
    $query  .= " WHERE ".$conditionData;
    $execute= $db->query($query);
   
   if($execute=== true){
      $msg= "Data was updated successfully";
  }else{
      $msg= $query;
  }
}
 return $msg;
}
 function validate($value) {
  $value = trim($value);
  $value = stripslashes($value);
  $value = htmlspecialchars($value);
  return $value;
 }
?>

<?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $cognome = $_POST['cognome'];
        $datetime = $_POST['datetime'];
        $telefono = $_POST['telefono'];
        $note = $_POST['note'];
        echo $datetime;
        $coperti = $_POST['coperti'];
        $query = "UPDATE prenotazioni SET nome = '$nome', cognome = '$cognome', datetime = '$datetime', coperti = '$coperti', telefono = '$telefono', note = '$note' WHERE id= $id";
        if ($conn->query($query) === TRUE) {
            $_SESSION['risp'] = 'Dati aggiornati con successo';
            header('Location:tabella.php');
            die();
        } else {
            echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
        }
    }
?>



<?php
$db = $conn;
$tableName = "prenotazioni";
$columns = ['id', 'nome','cognome','datetime', 'coperti', 'telefono', 'note'];

$fetchData = fetch_data($db, $tableName, $columns);

function fetch_data ($db, $tableName, $columns) {
 if(empty($db)){
  $msg = "Database connection error";
 }elseif (empty($columns) || !is_array($columns)) {
  $msg = "columns Name must be defined in an indexed array";
 }elseif(empty($tableName)){
   $msg = "Table Name is empty";
}else{
$columnName = implode(", ", $columns);
$query = "SELECT ".$columnName." FROM $tableName"." ORDER BY " . $columns[3];
$result = $db->query($query);

if($result == true){ 
 if ($result->num_rows > 0) {
    $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    $msg= $row;
 } else {
    $msg= "No Data Found"; 
 }
}else{
  $msg= mysqli_error($db);
}
}
return $msg;
}
?>


