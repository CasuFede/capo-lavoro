<?php
require 'developers.php';


?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Tabella modifica</title>
  <!--Bootstrap-->
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/headers/">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.9/xlsx.full.min.js"></script>

  </head>
  <style>
    body {
    margin: 1px;
    padding: 1px;
  }
  .form-inline {
    display: flex; 
    float: right;
    width: 275px;

  }

  .form-inline input[type="date"] {
    margin-right: 2px; /* Adjust spacing between inputs */
    margin-left: 2px; /* Adjust spacing between inputs */
  }

  .form-inline button {
    padding: 6px 12px;
    border: none;
    border-radius: 4px;
  }
  .container {
        max-width: 600px;
        margin: 50px auto;
        text-align: center;
      }

      .options {
        
        display: flex;
        justify-content: space-between;
      }

      .option {
        display: inline-block;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border: 1px solid #0d6efd;
        border-radius: 5px;
        transition: background-color 0.3s, color 0.3s;
      }

      .option:hover {
        background-color: #0d6efd;
        color: white;
}

</style>
  <body>
    <?php
    // Query per contare le righe con lo stesso campo
    $sql1 = "SELECT nome, cognome, telefono, COUNT(*) as conteggio FROM prenotazioni GROUP BY nome, cognome, telefono";
    $result1 = $conn->query($sql1);
    $output = [];
    $i = 0;
    if ($result1->num_rows > 0) {
        // Output dei risultati
        while($row = $result1->fetch_assoc()) {
            $output[$i]['Nome'] = $row["nome"];
            $output[$i]['Cognome'] = $row["cognome"];
            $output[$i]['Telefono'] = $row["telefono"];
            $output[$i]['Count'] = $row["conteggio"];

            $i++;
        }
    } else {
        $output = "No Data Found";
    }


    ?>
  <main>
  <div>
      <?php echo $deleteMsg??''; ?>
      <table class="table table-striped table-hover" id="data-table">
        <thead><tr><th scope="col">Id</th>
          <th scope="col">Nome</th>
          <th scope="col">Cognome</th> 
          <th scope="col">Telefono</th>
          <th scope="col">Num</th>
      </thead>
      <tbody>
        <?php
        if(is_array($fetchData)){      
          $sn=1;
          for ($i = 0; $i < count($output); $i++) {
              ?>
                <tr>
                  <td scope="row"><?php echo $sn; ?></td>
                  <td><?php echo $output[$i]['Nome']; ?></td>
                  <td><?php echo $output[$i]['Cognome']; ?></td>
                  <td><?php echo $output[$i]['Telefono']; ?></td>
                  <td><?php echo $output[$i]['Count'] ?></td>
                </tr>
              <?php
                $sn++;      
          }
        }else{ 
        ?>
        <tr>
          <td colspan="8">
      <?php echo $fetchData; ?>
          </td>
        <tr>
          <?php
        }
        ?>
          </tbody>
          </table>  
    </div>

    </main>
    <footer>
      <div class="container">
        <div class="options">
          <a href="tabella.php" class="option">Indietro</a>
          <button onclick="exportToExcel()" class="option">Esporta Excel</button>
        </div>
      </div>
      
    </footer>
      <?php
        if (!empty($_SESSION['risp'])) { ?>
        <script>
            window.alert('<?= $_SESSION['risp'] ?>');
        </script>
        <?php
            $_SESSION['risp'] = '';
        }
        ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.2/dist/chart.umd.js" integrity="sha384-eI7PSr3L1XLISH8JdDII5YN/njoSsxfbrkCTnJrzXt+ENP5MOVBxD+l6sEG4zoLp" crossorigin="anonymous"></script><script src="script.js"></script>
      <script>
        function resetDateField() {
          document.getElementById("date1").value = "<?php echo ""; ?>";
        }

        //esport excel
        function exportToExcel() {
          const table = document.getElementById('data-table');
          const wb = XLSX.utils.table_to_book(table, {sheet:"Sheet1"});
          XLSX.writeFile(wb, 'rubrica.xlsx');
        } 
        </script>
  </body>
</html>
<!---->