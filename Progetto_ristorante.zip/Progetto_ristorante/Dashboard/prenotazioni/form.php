<?php
require 'developers.php';
?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label, input, textarea {
            display: block;
            margin-bottom: 10px;
            width: 100%;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        .input-wrapper {
            display: flex;
        }
        .input-container {
            flex: 1;
           
        }
        textarea {
            position: relative; /* Posizione relativa per consentire il posizionamento assoluto */
        }

        /* Stile per la textarea ingrandita */
        textarea.expanded {
            width: 70%;
            height: 50%;
            z-index: 9999; /* Assicura che la textarea ingrandita sia sopra a tutti gli altri elementi */
            top: 25%; /* Posiziona la textarea al centro verticale */
            left: 15%; /* Posiziona la textarea al centro orizzontale */
            position: absolute; /* Posizione assoluta per centrare la textarea */
        }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>
  <body>
    
    <p><?php echo !empty($result)? $result:''; ?></p>

    <form action="developers.php" method="post">
    <h2 style="text-align: center;">Aggiornamento dati</h2>
        <input type="hidden" name="id" value="<?php echo $_GET['edit']; ?>">

        <label for="data">Data:</label>
        <input type="datetime-local" id="data" name="datetime"  value="<?php echo $editData['datetime']??''; ?>">
        <div class="input-wrapper">
            <div class="input-container">
                <label for="cognome">Cognome:</label>
                <input type="text" name="cognome" value="<?php echo $editData['cognome']??''; ?>">
            </div>
            <div class="input-container">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" value="<?php echo $editData['nome']??''; ?>">
            </div>
            
        </div>

        <label for="descrizione">Numero:</label>
        <input type="tel" name="telefono" value="<?php echo $editData['telefono']??''; ?>" required>

        <label for="coperti">Coperti:</label>
        <input type="number" name="coperti" step="1" value="<?php echo $editData['coperti']??''; ?>">

        <label for="coperti">Note:</label>
        <textarea name='note' onclick='espandiTextarea(this)'><?php echo $editData['note']??''; ?></textarea>

        <button type="submit" value="Invio" class="btn btn-primary">Save</button>
    </form>
   
    <script>
                /*textarea*/
        // Funzione per gestire il clic sulla textarea
        function espandiTextarea(textarea) {
        textarea.classList.add("expanded");
        textarea.focus(); // Imposta il focus sulla textarea ingrandita
        textarea.style.zIndex = "9999"; // Imposta il valore di z-index sopra a tutti gli altri elementi
        }

        // Funzione per gestire l'uscita dalla textarea
        function rimpicciolisciTextarea(textarea) {
        textarea.classList.remove("expanded");
        }

        // Aggiunta di un listener per l'uscita dalla textarea
        document.addEventListener("focusout", function(event) {
        if (event.target.tagName === "TEXTAREA") {
            rimpicciolisciTextarea(event.target);
        }
        });

        // Aggiunta di un listener per il clic sulla textarea
        document.addEventListener("click", function(event) {
        if (event.target.tagName === "TEXTAREA") {
            espandiTextarea(event.target);
        }
        });
    </script>

  </body>
</html>

