<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Esporta Excel</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.9/xlsx.full.min.js"></script>
</head>
<body>

<table id="data-table">
  <thead>
    <tr>
      <th>Nome/th>
      <th>Cognome</th>
      <th>Telefono</th>
      <th>Conteggio</th>
    </tr>
  </thead>
  <tbody>
    <?php


    // Query per recuperare i dati
    $sql = "SELECT nome, cognome, telefono, COUNT(*) as conteggio FROM prenotazioni GROUP BY nome, cognome, telefono";
    $result = $conn->query($sql);

    // Stampare i dati come righe della tabella HTML
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["nome"]. "</td><td>" . $row["cognome"]. "</td><td>" . $row["telefono"]. "</td><td>" . $row["conteggio"]. "</td></tr>";
      }
    } else {
      echo "0 risultati";
    }
    $conn->close();
    ?>
  </tbody>
</table>

<button onclick="exportToExcel()">Esporta Excel</button>

<script>
function exportToExcel() {
  const table = document.getElementById('data-table');
  const wb = XLSX.utils.table_to_book(table, {sheet:"Sheet1"});
  XLSX.writeFile(wb, 'dati.xlsx');
}
</script>

</body>
</html>
