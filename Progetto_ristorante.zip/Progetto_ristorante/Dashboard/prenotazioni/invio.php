<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>  

<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        #primo, #secondo{
            display: block !important;
            margin-bottom: 10px !important;
            width: 100% !important;
        }
        
        #input1, #input2 {
            height: 22px;
            
        } 
        textarea {
            display: block;
            margin-bottom: 10px;
            width: 97.5%;
        }
        .button {
            display: block !important;
            margin-bottom: 10px !important;
            width: 100% !important;
        }
        select, label, input {
            display: block;
            margin-bottom: 10px;
            width: 97%;
        }
        .nome_select {
            width: 99.5% !important;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        .input-wrapper {
            display: flex;
            
        }
        .input-container {
            flex: 1;
            margin-right: 10px; /* Aggiungi margine tra gli input se necessario */
            
        }
        .input-wrapper1 {
            display: flex;
            
        }
        .input-container1 {
            flex: 1;
        }
        .input-container2 {
            flex: 1;
            margin-left: -4px;
        }

         /* Stile di base per la textarea */
        textarea {
            position: relative; /* Posizione relativa per consentire il posizionamento assoluto */
        }

        /* Stile per la textarea ingrandita */
        textarea.expanded {
            width: 70%;
            height: 50%;
            z-index: 9999; /* Assicura che la textarea ingrandita sia sopra a tutti gli altri elementi */
            top: 25%; /* Posiziona la textarea al centro verticale */
            left: 15%; /* Posiziona la textarea al centro orizzontale */
            position: absolute; /* Posizione assoluta per centrare la textarea */
        }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>
  <body>
    <form name="dati" id="dati" action="ricezione.php" method="post">
    <h2 style="text-align: center;">Inserisci prenotazione</h2>
    
        <input type="text" id="searchInput" onkeyup="filterOptions()" placeholder="Cerca...">
        <?php $phpArray = generateSelectOptions("category", $conn); ?>
        <!-- Aggiungi altri select se necessario -->
    
        <script>var phpArray = <?php echo $phpArray; ?>;</script>
    
        <script>var phpArray = <?php echo json_encode($arr); ?>;</script>
	</select>
    <label for="data">Data-Ora:</label>
    <div class="input-wrapper">
        <div class="input-container1">
            <input type="date" id="data" name="data">
        </div>
                
                <div class="input-container1">
                    <select id="input1" name="ora" class="form-select" required>
                    <option selected>Ore</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    <option value="13">13</option>
                    <option value="14">14</option>
                    <option value="15">15</option>
                    <option value="16">16</option>
                    <option value="17">17</option>
                    <option value="18">18</option>
                    <option value="19">19</option>
                    <option value="20">20</option>
                    <option value="21">21</option>
                    <option value="22">22</option>
                    <option value="23">23</option>
                    
                    </select>
                    </div>
                <div class="input-container2">
                    <select id="input2" name="minuti" class="form-select"required>
                    <option selected>Minuti</option>
                    <option value="00">00</option>
                    <option value="15">15</option>
                    <option value="30">30</option>
                    <option value="45">45</option>
                    </select>
                </div>
        </div>
		
        <!--<label for="data">Data:</label>
        <input type="datetime-local" id="data" name="datatime" min="2024-03-02T08:00" max="2024-03-02T23:00" step="900" required>-->
        <div class="input-wrapper">
			<div class="input-container">
                <label for="cognome">Cognome:</label>
                <input type="text" id="primo" name="cognome"  placeholder="Bianco" required>
            </div>
            <div class="input-container">
                <label for="nome">Nome:</label>
                <input type="text" id="secondo" name="nome" placeholder="Francesco" required>
            </div>
        </div>
        <label for="descrizione">Numero:</label>
        <input type="tel" name="telefono" placeholder="000 000 0000" required>

        <label for="coperti">Coperti:</label>
        <input type="number" name="coperti" step="1"  placeholder="3" required>

        <label for="coperti">Note:</label>
        <textarea name='note' placeholder='Clicca qui per scrivere' onclick='espandiTextarea(this)'></textarea>

        <input class="button" type="submit" value="Invia">
    </form>
   
    <script>
                /*textarea*/
        // Funzione per gestire il clic sulla textarea
        function espandiTextarea(textarea) {
        textarea.classList.add("expanded");
        textarea.focus(); // Imposta il focus sulla textarea ingrandita
        textarea.style.zIndex = "9999"; // Imposta il valore di z-index sopra a tutti gli altri elementi
        }

        // Funzione per gestire l'uscita dalla textarea
        function rimpicciolisciTextarea(textarea) {
        textarea.classList.remove("expanded");
        }

        // Aggiunta di un listener per l'uscita dalla textarea
        document.addEventListener("focusout", function(event) {
        if (event.target.tagName === "TEXTAREA") {
            rimpicciolisciTextarea(event.target);
        }
        });

        // Aggiunta di un listener per il clic sulla textarea
        document.addEventListener("click", function(event) {
        if (event.target.tagName === "TEXTAREA") {
            espandiTextarea(event.target);
        }
        });

        /* Funzione per aggiornare gli input */
    function updateInputs() {
        console.log("Funzione updateInputs() chiamata.");

        // Ottenere la select tramite il nome
        var selectElement = document.querySelector('select[name="nome_select"]');

        // Ottenere il valore selezionato dalla select
        var selectedOption = selectElement.options[selectElement.selectedIndex];
        var selectedValue = selectedOption.value;

        console.log("Valore selezionato:", selectedValue); // Verifica se il valore selezionato è corretto
        
        // Impostare il valore ottenuto dalla select sui due input
        document.querySelector('input[name="nome"]').value = phpArray[selectedValue]['Nome'];
        document.querySelector('input[name="cognome"]').value = phpArray[selectedValue]['Cognome'];
        document.querySelector('input[name="telefono"]').value = phpArray[selectedValue]['Telefono'];
    }
   
        function filterOptions() {
            var input, filter, select, option, i;
            input = document.getElementById("searchInput");
            filter = input.value.toUpperCase();
            select = document.getElementById("category"); // Cambia qui con l'id del tuo select
            option = select.getElementsByTagName("option");
            for (i = 0; i < option.length; i++) {
                if (option[i].textContent.toUpperCase().indexOf(filter) > -1) {
                    option[i].style.display = "";
                } else {
                    option[i].style.display = "none";
                }
            }
        }
    </script>

    <?php
    function generateSelectOptions($selectId, $conn) {
        // Query per recuperare le opzioni dalla tabella
        $sql2 = "SELECT DISTINCT nome, cognome, telefono FROM prenotazioni ORDER BY nome ASC"; // Cambia qui con la tua query
        $result2 = $conn->query($sql2);
        $i = 0;
        if ($result2 !== false && $result2->num_rows > 0) {
            // Output delle opzioni del menu a tendina
            echo '<select id=' . $selectId . ' class="nome_select" name="nome_select" onchange="updateInputs()">';
            echo "<option value='all'>Tutte le categorie</option>";
            while($row2 = $result2->fetch_assoc()) {
                $arr[$i]['Telefono'] = $row2['telefono']; 
                $arr[$i]['Nome'] = $row2['nome']; 
                $arr[$i]['Cognome'] = $row2['cognome']; 
                echo "<option value='".$i."'>".$row2['nome']." ".$row2['cognome']. " " . $row2['telefono'] . "</option>";
                $i++;
            }
            
            echo "</select>";
        } else {
            echo "<select id='" . $selectId . "'>";
            echo "<option value=''>Nessuna categoria trovata</option>";
            echo "</select>";
        }
        $phpArray = json_encode($arr);

        // Restituisci $phpArray così può essere utilizzato fuori dalla funzione
        return $phpArray;
    }
    ?>
    
  </body>
</html>


