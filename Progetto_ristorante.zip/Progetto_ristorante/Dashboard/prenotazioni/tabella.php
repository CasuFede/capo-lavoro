<?php
require 'developers.php';
?>  
<!DOCTYPE html>
<html lang="it" data-bs-theme="auto">
<head>
  <link rel="shortcut icon" href="favicon.ico"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="nothing">
  <meta name="author" content="anonymous">
  <title>Prenotazioni</title>
  <!--Bootstrap-->
  <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/headers/">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
  body {
    margin: 1px;
    padding: 1px;
  }
  .form-inline {
    display: flex; 
    float: right;
    width: 275px;
  }

  .form-inline input[type="date"] {
    margin-right: 2px; /* Adjust spacing between inputs */
    margin-left: 2px; /* Adjust spacing between inputs */
  }

  .form-inline button {
    padding: 6px 12px;
    border: none;
    border-radius: 4px;
  }
  .container {
    max-width: 600px;
    margin: 50px auto;
    text-align: center;
  }

  .options {
    display: flex;
    justify-content: space-between;
  }

  .option {
    display: inline-block;
    padding: 10px 20px;
    background-color: #0d6efd;
    color: white;
    text-decoration: none;
    border: 1px solid #0d6efd;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s;
  }

  .option:hover {
    background-color: #0d6efd;
    color: white;
  }
  
  .left-button {
    position: fixed;
    left: 20px;
    bottom: 20px;
  }

  .right-button {
      position: fixed;
      right: 20px;
      bottom: 20px;
  }
  .right-button:hover, .left-button:hover {
    background-color: #0d6efd;
    color: white;
  }
  .right-button, .left-button{
    padding: 10px 20px;
    background-color: #0d6efd;
    color: white;
    text-decoration: none;
    border: 1px solid #0d6efd;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s;
  }
  textarea {
    width: 150px;
    height: 22px;
    padding-top: 0;
    position: relative;
  }

  /* Stile per la textarea ingrandita */
  textarea.expanded {
      width: 70%;
      height: 50%;
      z-index: 9999;
      top: 25%;
      left: 15%;
      position: absolute;
  }
.select {
	background-color: lightblue !important;
}
</style>
<body>
<?php
  $var = 0;
$var1 = 0;
$tmp1 = '';
if ($_SERVER["REQUEST_METHOD"] === "GET" && !empty($_GET['date1'])) {
  $date1 = mysqli_real_escape_string($conn, $_GET["date1"]);
} else {
  $date1 = date('Y-m-d');
}
?>
<header>
  <form id="dateForm" action="tabella.php" method="GET">
    <div class="form-inline">
      <button onclick="resetDateField()" type="submit" class="btn btn-secondary">Reset</button>
      <input type="date" value="<?php echo $date1;?>" class="form-control" name="date1" id="date1">
      <button type="submit" value="Submit" class="btn btn-primary">Invio</button>
    </div>
  </form> 
</header>

<main>
  <div>
    <?php echo $deleteMsg??''; ?>
    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th scope="col">Data</th>
          <th scope="col">Ora</th>
          <th scope="col">Persona</th>
          <th scope="col">Coperti</th>
          <th scope="col">Note</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if(is_array($fetchData)){      
          $sn=1;
          foreach($fetchData as $data){
            $prova = $data['datetime']??'';
            $dat = explode(" ", $data['datetime']??'');
            $cerca = $dat[0];
            $tmp = explode(":", $dat[1]);
            $fine = $tmp[0] . ":" . $tmp[1];
            if ($cerca == $date1) {
              $tmp1 = $data['nome']??'';
              if ($fine >= 17 && $var == 0) {
                $var++;
                ?>
              	<td class="select">Cena</td>
                  <?php
              } elseif ($fine <= 17 && $var1 == 0) {
                $var1++;
              	?>
              	<td class="select">Pranzo</td>
                  <?php
              }
        ?>
        <tr>
          <td><?php echo $cerca; ?></td>
          <td><?php echo $fine; ?></td>
          <td><?php echo $data['cognome'] . " " . $data['nome']; ?></td>
          <td><?php echo $data['coperti']??''; ?></td>
          <td><textarea name='note' onclick='espandiTextarea(this)'><?php echo $data['note']??''; ?></textarea></td>
          <td ><a href="form.php?edit=<?php echo $data['id']; ?>" >Modifica</a>
          <a href="delete.php?edit=<?php echo $data['id']; ?>" >Elimina</a></td>
        </tr>
        <?php
          $sn++;
        } 
      }
    }else{ 
    ?>
    <tr>
      <td colspan="9">
        <?php echo $fetchData; ?>
      </td>
    <tr>
      <?php
    }
    if ($tmp1 == '') {
    ?>
    <tr>
      <td colspan="9">
        <?php echo "No Data Found"; ?>
      </td>
    <tr>
      <?php
    }
    ?>
  </tbody>
</table>  
</div>
</main>
<footer>
  <div class="container">
    <div class="options">
      <a href="../prenotazioni.php" class="option">Indietro</a>
      <a href="invio.php" class="option">Inserimento</a>
      <a href="esporta.php" class="option">Esporta</a>
      <a href="info.php" class="option">Rubrica</a>
    </div>
  </div>
  <button type="button" class="right-button" onclick="changeDate(1)">>></button>
  <button type="button" class="left-button" onclick="changeDate(-1)"><<</button>
</footer>
<?php
if (!empty($_SESSION['risp'])) { ?>
<script>
  window.alert('<?= $_SESSION['risp'] ?>');
</script>
<?php
$_SESSION['risp'] = '';
}
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.2/dist/chart.umd.js" integrity="sha384-eI7PSr3L1XLISH8JdDII5YN/njoSsxfbrkCTnJrzXt+ENP5MOVBxD+l6sEG4zoLp" crossorigin="anonymous"></script>
<script>
  function resetDateField() {
    document.getElementById("date1").value = "<?php echo date('Y-m-d'); ?>";
  }

  function changeDate(increment) {
    var currentDate = new Date('<?php echo $date1; ?>');
    currentDate.setDate(currentDate.getDate() + increment);
    var formattedDate = currentDate.toISOString().split('T')[0];
    document.getElementById("date1").value = formattedDate;
    document.getElementById("dateForm").submit();
  }

  /*textarea*/
  function espandiTextarea(textarea) {
    textarea.classList.add("expanded");
    textarea.focus();
    textarea.style.zIndex = "9999";
  }

  function rimpicciolisciTextarea(textarea) {
    textarea.classList.remove("expanded");
  }

  document.addEventListener("focusout", function(event) {
    if (event.target.tagName === "TEXTAREA") {
      rimpicciolisciTextarea(event.target);
    }
  });

  document.addEventListener("click", function(event) {
    if (event.target.tagName === "TEXTAREA") {
      espandiTextarea(event.target);
    }
  });
</script>
</body>
