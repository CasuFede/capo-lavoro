
<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<?php

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $id = $_GET['edit'];
    $query = "SELECT * FROM prenotazioni";
      $result = $conn->query($query);
      if ($result->num_rows > 0) {     
       // Verifica se il file esiste nella cartella
    
        $query = "DELETE FROM prenotazioni WHERE id = $id";
        if ($conn->query($query) === TRUE) {
            $_SESSION['risp'] = 'Dati eliminati con successo nel database';
            header('Location:tabella.php');
            die();
        } else {
            echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
        }
    }
    
}


?>