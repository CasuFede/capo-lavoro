<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Esporta Excel</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.9/xlsx.full.min.js"></script>
<style>
  form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f7f7f7;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }

  .container {
    max-width: 800px;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  form {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  label {
    margin-bottom: 10px;
  }

  input[type="date"] {
    padding: 5px;
    border-radius: 3px;
    border: 1px solid #ccc;
    margin-bottom: 10px;
  }

  button {
    padding: 7px 50px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    cursor: pointer;
  }

  button:hover {
    background-color: #0056b3;
  }

  #data-table {
    display: none;
  }
  .input-wrapper {
            display: flex;
            
        }
        .input-container {
            flex: 1;
            
        }
        .input-container1 {
            flex: 1;
        }
        .option {
    display: inline-block;
    padding: 10px 20px;
    background-color: #0d6efd;
    color: white;
    text-decoration: none;
    border: 1px solid #0d6efd;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s;
  }

  .option:hover {
    background-color: #0d6efd;
    color: white;
  }
    </style>
</head>
<body>

<form id="date-form">
  <h2>Esportazione prenotazioni</h2>
    <div class="input-wrapper">
			<div class="input-container">
        <label for="start-date">Data di inizio:</label>
        <input type="date" id="start-date" name="start-date">
      </div>
        <div class="input-container">
          <label for="end-date">Data di fine:</label>
          <input type="date" id="end-date" name="end-date">
        </div>
        <div class="input-container">
        <label for="end-date">Esporta Excel:</label>
        <button type="button" onclick="exportToExcel()">Invio</button>
        </div>
    </div>
    <a href="tabella.php" class="option">Indietro</a>
</form>

<table id="data-table">
  <thead>
    <tr>
      <th>Data</th>
      <th>Ora</th>
      <th>Persona</th>
      <th>Coperti</th>
      <th>Note</th>
    </tr>
  </thead>
  <tbody>
    <?php
    

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['start-date']) && isset($_POST['end-date'])) {
        $start_date = $_POST['start-date'];
        $end_date = $_POST['end-date'];

        // Query per recuperare i dati tra le due date
        $sql = "SELECT * FROM prenotazioni WHERE datetime BETWEEN '$start_date' AND '$end_date' ORDER BY datetime";
        $result = $conn->query($sql);

        // Stampare i dati come righe della tabella HTML
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $prova = $row['datetime'];
                $datetime = explode(" ", $prova);
                echo "<tr><td>" . $datetime[0]. "</td><td>" . $datetime[1]. "</td><td>" . $row["nome"]. " " . $row["cognome"]. "</td><td>" . $row["coperti"]. "</td><td>" . $row["note"]. "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nessun risultato tra le date selezionate.</td></tr>";
        }
        $conn->close();
        exit(); // Assicura che non venga stampato alcun altro output HTML
    }
    ?>
  </tbody>
</table>

<script>
function exportToExcel() {
  const startDate = document.getElementById('start-date').value;
  const endDate = document.getElementById('end-date').value;

  const form = document.getElementById('date-form');
  const formData = new FormData(form);
  formData.append('start-date', startDate);
  formData.append('end-date', endDate);

  fetch(window.location.href, {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    const table = document.getElementById('data-table');
    table.innerHTML = data;
    
    const wb = XLSX.utils.table_to_book(table, {sheet:"Sheet1"});
    XLSX.writeFile(wb, 'prenotazioni.xlsx');
  })
  .catch(error => console.error('Errore durante l\'esportazione Excel:', error));
}
</script>

</body>
</html>



