<?php
// Verifica se il parametro 'table' è stato ricevuto
if(isset($_GET['table'])) {
    $table = $_GET['table'];

    // Simulazione di dati di ordinazioni per i tavoli
    $orders = [];
    if ($table === 'table1') {
        $orders = ['Pizza Margherita', 'Spaghetti Carbonara'];
    } elseif ($table === 'table2') {
        $orders = ['Insalata mista', 'Bistecca alla griglia'];
    }

    // Restituzione dei dati come JSON
    header('Content-Type: application/json');
    echo json_encode(['orders' => $orders]);
} else {
    // Se il parametro 'table' non è stato ricevuto, restituisci un messaggio di errore
    echo json_encode(['error' => 'Parametro "table" non specificato']);
}
?>
