<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ristorante</title>
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        display: flex;
    }

    #sidebar {
        width: 100px;
        height: 100vh;
        background-color: #f0f0f0;
    }

    #restaurant {
        flex: 1;
        height: 100vh;
        background-color: #ccc;
        display: flex;
        flex-wrap: wrap;
        padding: 10px;
        align-content: flex-start;
    }

    .table {
        width: 80px;
        height: 80px;
        background-color: gray;
        border: 1px solid black;
        cursor: pointer;
        margin: 5px;
        position: absolute;
        user-select: none;
    }

    .long-table {
        width: 160px;
    }

    .table.selected {
        background-color: orange;
    }

    #addTableBtn, #addLongTableBtn, #removeTableBtn {
        display: block;
        margin: 10px;
    }
</style>
</head>
<body>
<div id="sidebar">
    <button id="addTableBtn">Aggiungi tavolo</button>
    <button id="addLongTableBtn">Aggiungi tavolo lungo</button>
    <button id="removeTableBtn">Rimuovi tavolo</button>
</div>
<div id="restaurant">
    <!-- Tavoli saranno aggiunti qui -->
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    var restaurant = document.getElementById("restaurant");
    var tableCount = 0;
    var selectedTable = null;
    var initialX = 0;
    var initialY = 0;
    var offsetX = 0;
    var offsetY = 0;

    function addTable(isLong) {
        tableCount++;
        var newTable = document.createElement("div");
        newTable.classList.add("table");
        if (isLong) {
            newTable.classList.add("long-table");
        }
        newTable.id = "table" + tableCount;
        newTable.textContent = "Tavolo " + tableCount;
        newTable.addEventListener("mousedown", startDragging);
        restaurant.appendChild(newTable);
    }

    function startDragging(e) {
        selectedTable = e.target;
        initialX = e.clientX - selectedTable.offsetLeft;
        initialY = e.clientY - selectedTable.offsetTop;
        offsetX = e.clientX;
        offsetY = e.clientY;
        document.addEventListener("mousemove", dragTable);
        document.addEventListener("mouseup", stopDragging);
    }

    function dragTable(e) {
        if (selectedTable) {
            var newX = e.clientX - initialX;
            var newY = e.clientY - initialY;
            selectedTable.style.left = newX + "px";
            selectedTable.style.top = newY + "px";
        }
    }

    function stopDragging() {
        document.removeEventListener("mousemove", dragTable);
        document.removeEventListener("mouseup", stopDragging);
    }

    function selectTable(e) {
        if (selectedTable) {
            selectedTable.classList.remove("selected");
        }
        selectedTable = e.target;
        selectedTable.classList.add("selected");
    }

    function removeTable() {
        if (selectedTable) {
            var confirmation = confirm("Vuoi confermare la rimozione del tavolo?");
            if (confirmation) {
                selectedTable.parentNode.removeChild(selectedTable);
                selectedTable = null;
            }
        } else {
            alert("Seleziona un tavolo prima di rimuoverlo.");
        }
    }

    var addTableBtn = document.getElementById("addTableBtn");
    var addLongTableBtn = document.getElementById("addLongTableBtn");
    var removeTableBtn = document.getElementById("removeTableBtn");
    addTableBtn.addEventListener("click", function() {
        addTable(false);
    });
    addLongTableBtn.addEventListener("click", function() {
        addTable(true);
    });
    removeTableBtn.addEventListener("click", removeTable);

    // Rimuovi la classe "selected" quando si inizia a trascinare il tavolo
    var tables = document.querySelectorAll(".table");
    tables.forEach(function(table) {
        table.addEventListener("mousedown", function() {
            if (selectedTable) {
                selectedTable.classList.remove("selected");
            }
        });
    });
});
</script>
</body>
</html>
