<?php
session_start();
require '../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../login.php');
    die();
}
require '../connection.php';
?> 
<!DOCTYPE html>
<html>
    <head>
        <title>Ricezione dati</title>
        <meta charset="UTF-8" />
    </head>
    <body>
         
        <h1>Ricezione dati</h1>
        <?php
        $p1 = true;
        $p2 = true;
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            if (empty($_POST["nome"])) {
                $p1 = false;
            } else {
                $nome = mysqli_real_escape_string($conn, $_POST["nome"]);
            }
            
            if (empty($_POST["ore"])) {
                $p1 = false;
            } else {
                $ore = mysqli_real_escape_string($conn, $_POST["ore"]);
            }

            if (empty($_POST["costo"])) {
                $p1 = false;
            } else {
                $costo = mysqli_real_escape_string($conn, $_POST["costo"]);
            }  

            if (empty($_POST["tipo"])) {
                $p1 = false;
            } else {
                $tipo = mysqli_real_escape_string($conn, $_POST["tipo"]);
            } 

            if ($p1 != false) { 
                $date = date("d-m-Y");
                $query = "INSERT INTO date_data (codPersona, giorno, nrOre, costoOre, codTipoOra)
                VALUES('$nome', '$date', '$ore', '$costo', '$tipo')";
                if($conn->query($query) === TRUE){
                    header('Location:invio.php');
                    $_SESSION['message'] = "new records created";
                    die();
                }else{
                    echo "Inserimento dati lavoratore errore".$conn->error;
                }
            } 
            if ($p2 != false) {
                if (empty($_POST["motivo"])) {
                    $p2 = false;
                } else {
                    $motivo = mysqli_real_escape_string($conn, $_POST["motivo"]);
                } 
                if (empty($_POST["file"])) {
                    $p2 = false;
                } else {
                    $media = mysqli_real_escape_string($conn, $_POST["file"]);
                }
                if (empty($_POST["scadenza"])) {
                    $p2 = false;
                } else {
                    $scadenza = mysqli_real_escape_string($conn, $_POST["scadenza"]);
                } 
                if (empty($_POST["importo"])) {
                    $p2 = false;
                } else {
                    $importo = mysqli_real_escape_string($conn, $_POST["importo"]);
                } 
                // Controlla se è stato caricato un file senza errori
                if ($_FILES["file"]["error"] == UPLOAD_ERR_OK) {
                    
                    // Percorso della cartella in cui salvare il file
                    $uploadDirectory = "fatture/";
                   
                    // Crea la cartella se non esiste
                    if (!file_exists($uploadDirectory)) {
                        mkdir($uploadDirectory, 0777, true);
                    }

                    // Nome del file
                    $nomeFile = mysqli_real_escape_string($conn, $_FILES["file"]["name"]);
                    $tmp = explode(".", $nomeFile);
                    $tipo = $tmp[1];
                    $size = mysqli_real_escape_string($conn, $_FILES["file"]["size"]);
                    echo $size;
                    echo "           ";

                    $filename = 'variabile_fattura.txt';

                    // Leggi il valore corrente dalla memoria o imposta un valore di default
                    $variabile = file_exists($filename) ? intval(file_get_contents($filename)) : 0;

                    // Ottieni la data corrente
                    //$dataCorrente = date('Y-m-d');
                    // Ottieni la data dell'ultima modifica del file (se esiste)
                    //$dataUltimaModifica = file_exists($filename) ? date('Y-m-d', filemtime($filename)) : null;
                    
            
                    

                    // Percorso completo del file
                    $targetPath = $uploadDirectory . $variabile . $nomeFile;

                    // Cambia il valore della variabile
                    $variabile++;

                    // Salva il nuovo valore nel file
                    file_put_contents($filename, $variabile);
                    // Sposta il file dalla posizione temporanea alla cartella di destinazione
                    if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetPath)) {
                        echo "Il file $nomeFile è stato caricato con successo.";
                    } else {
                        echo "Si è verificato un errore durante il caricamento del file.";
                    }

                } else {
                    echo "Si è verificato un errore durante l'upload del file.";
                }
                
                $giorno = date("Y-m-d");
                $query = "INSERT INTO fatture (dataIns, nome, datiFile, importo, Scadenza, stato)
                VALUES('$giorno', '$motivo', '$targetPath', '$importo', '$scadenza', 'niente')";
                if($conn->query($query) === TRUE){
                    header('Location:invio.php');
                    $_SESSION['message1'] = "Fattura inserita con successo";
                    die();
                }else{
                    echo "Inserimento fattura errore".$conn->error;
                }
            }
            
        } else {
            echo "<p class=\"red\">Errore</p>";
            header('Location:invio.php');
            die();
        }
        ?>
        <?php include "../close_connection.php"; ?>
    </body>
</html>