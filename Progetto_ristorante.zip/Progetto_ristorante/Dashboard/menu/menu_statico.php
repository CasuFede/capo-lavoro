<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menu del Ristorante</title>
  <link rel="stylesheet" href="styles.css">
  <style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

header {
  background-color: #333;
  color: white;
  padding: 20px;
  text-align: center;
}

.menu {
  padding: 20px;
}

.category {
  margin-bottom: 20px;
}

.category h2 {
  margin-top: 0;
}

.item {
  background-color: #f4f4f4;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
}

.item h3 {
  margin-top: 0;
}

.item span {
  font-weight: bold;
  display: block;
  margin-top: 10px;
}

/* Stili del modal */
/* Stili del modal */
.modal {
  display: none;
  position: fixed;
  z-index: 100;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  overflow: auto;
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  display: block;
  max-width: 80%;
  max-height: 80%;
  position: relative;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.close {
  color: #fff;
  font-size: 40px;
  font-weight: bold;
  position: absolute;
  top: 10px;
  right: 25px;
  cursor: pointer;
}

  </style>
  <script>
    function showImage(imageUrl) {
        var modal = document.getElementById("modal");
        var modalImg = document.getElementById("modalImg");
        modal.style.display = "block";
        modalImg.src = imageUrl;
    }

    function closeImage() {
        var modal = document.getElementById("modal");
        modal.style.display = "none";
    }
    document.addEventListener("DOMContentLoaded", function() {
        var modal = document.getElementById("modal");
        modal.style.display = "none";
    });
  </script>
</head>
<body>
  <header>
    <h1>Menu del Ristorante</h1>
  </header>
  
  <section class="menu">
    <div class="category">
      <h2>Antipasti</h2>
      <div class="item" onclick="showImage('image/carbonara.jpg')">
        <h3>Bruschetta</h3>
        <p>Pomodoro, basilico, olio d'oliva</p>
        <span>Prezzo: $8</span>
      </div>
      <div class="item" onclick="showImage('image/bruschetta.jpg')">
        <h3>Caprese</h3>
        <p>Mozzarella di bufala, pomodoro, basilico</p>
        <span>Prezzo: $10</span>
      </div>
    </div>

    <div class="category">
      <h2>Primi</h2>
      <div class="item" onclick="showImage('image/bruschetta.jpg')">
        <h3>Spaghetti alla Carbonara</h3>
        <p>Pasta, uova, guanciale, pecorino</p>
        <span>Prezzo: $12</span>
      </div>
      <div class="item" onclick="showImage('image/bruschetta.jpg')">
        <h3>Risotto ai Funghi</h3>
        <p>Riso, funghi porcini, brodo, parmigiano</p>
        <span>Prezzo: $14</span>
      </div>
    </div>

    <div class="category">
      <h2>Secondi</h2>
      <div class="item" onclick="showImage('image/bruschetta.jpg')">
        <h3>Filetto di Manzo</h3>
        <p>Filetto di manzo, salsa al pepe verde</p>
        <span>Prezzo: $20</span>
      </div>
      <div class="item" onclick="showImage('image/bruschetta.jpg')">
        <h3>Pollo alla Griglia</h3>
        <p>Pollo alla griglia, patate arrosto</p>
        <span>Prezzo: $16</span>
      </div>
    </div>

    <div class="category">
      <h2>Dessert</h2>
      <div class="item" onclick="showImage('image/bruschetta.jpg')">
        <h3>Tiramisù</h3>
        <p>Savoiardi, mascarpone, caffè</p>
        <span>Prezzo: $8</span>
      </div>
      <div class="item" onclick="showImage('image/bruschetta.jpg')">
        <h3>Panna Cotta</h3>
        <p>Panna, zucchero, gelatina</p>
        <span>Prezzo: $7</span>
      </div>
    </div>
  </section>
  <div id="modal" class="modal">
    <span class="close" onclick="closeImage()">&times;</span>
    <img class="modal-content" id="modalImg">
  </div>
</body>
</html>