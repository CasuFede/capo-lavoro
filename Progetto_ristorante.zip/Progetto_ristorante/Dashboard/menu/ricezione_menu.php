<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?> 
    <!DOCTYPE html>
    <html>
        <head>
            <title>Ricezione dati</title>
            <meta charset="UTF-8" />
        </head>
        <body>
             
            <h1>Ricezione dati</h1>
            <?php
            $p1 = true;
            if ($_SERVER["REQUEST_METHOD"] === "POST") {
                if (empty($_POST["sezione"])) {
                    $p1 = false;
                } else {
                    $sezione = mysqli_real_escape_string($conn, $_POST["sezione"]);
                }
                
                if (empty($_POST["nome"])) {
                    $p1 = false;
                } else {
                    $nome = mysqli_real_escape_string($conn, $_POST["nome"]);
                }
                if (empty($_POST["descrizione"])) {
                    $descrizione = "";
                } else {
                    $descrizione = mysqli_real_escape_string($conn, $_POST["descrizione"]);
                }
                if (empty($_POST["prezzo"])) {
                    $p1 = false;
                } else {
                    $prezzo = mysqli_real_escape_string($conn, $_POST["prezzo"]);
                }  
                
                if ($_FILES["file"]["error"] == UPLOAD_ERR_OK) {
                    // Percorso della cartella in cui salvare il file
                    $uploadDirectory = "image/";

                    // Crea la cartella se non esiste
                    if (!file_exists($uploadDirectory)) {
                        mkdir($uploadDirectory, 0777, true);
                    }

                    // Nome del file
                    $nomeFile = mysqli_real_escape_string($conn, $_FILES["file"]["name"]);
                    //$tmp = explode(".", $nomeFile);
                    //$tipo = $tmp[1];
                    $size = mysqli_real_escape_string($conn, $_FILES["file"]["size"]);
                    /*echo $size;
                    echo "           ";*/

                    // Percorso completo del file
                    $targetPath = $uploadDirectory . $nomeFile;

                    // Sposta il file dalla posizione temporanea alla cartella di destinazione
                    if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetPath)) {
                        echo "Il file $nomeFile è stato caricato con successo.";
                    } else {
                        echo "Si è verificato un errore durante il caricamento del immagine.";
                    }
                } else {
                    echo "Si è verificato un errore durante l'upload del immagine.";
                }

                if ($p1 != false) { 
                    $query = "INSERT INTO menu (sezione, nome, percorso, descrizione, prezzo)
                    VALUES('$sezione', '$nome', '$targetPath', '$descrizione', '$prezzo')";
                    if($conn->query($query) === TRUE){
                        header('Location:menu_table.php');
                        die();
                    }else{
                        echo "Inserimento errore".$conn->error;
                    }
                } else {
                    echo "<p class=\"red\">Errore</p>";
                    header('Location:menu_table.php');
                    die();
                }
                
            } else {
                echo "<p class=\"red\">Errore</p>";
                header('Location:menu_table.php');
                die();
            }
            ?>
            <?php include "../close_connection.php"; ?>
        </body>
    </html>