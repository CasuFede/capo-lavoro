<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?> 
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label, input, select {
            display: block;
            margin-bottom: 10px;
            width: 98%;
        }
        select {
            width: 100%;
        }
        input[type="submit"] {
            width: 101%;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        
    </style>

  </head>
  <body>
     
    
    <form name="dati" id="dati" action="ricezione_menu.php" method="post" enctype="multipart/form-data">
    <h2 style="text-align: center;">Inserisci i tuoi dati</h2>
        <label for="sezione">Seleziona un piatto:</label>
            <select id="sezione" name="sezione" required>
                <option value="Antipasti">Antipasti</option>
                <option value="Primi">Primi</option>
                <option value="Secondi">Secondi</option>
                <option value="Dolci">Dolci</option>
                <option value="Vini">Vini</option>
                <option value="Bibite">Bibite</option>
            </select>
        
        <label for="nome">Nome piatto:</label>
        <input type="text" id="nome" name="nome" required>
       
        <label for="descrizione">Descrizione:</label>
        <input type="text" id="descrizione" name="descrizione">

        <label for="file">Seleziona un immagine:</label>
        <input type="file" name="file" id="file" required>

        <label for="prezzo">Inserire il prezzo:</label>
        <input type="number" name="prezzo" id="prezzo" step="0.01" required>
        
        <input type="submit" value="Invia">
    </form>
   

  </body>
</html>
