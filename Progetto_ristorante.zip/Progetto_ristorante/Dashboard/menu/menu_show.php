<?php
  require 'developers_menu.php';
?> 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menu del Ristorante</title>
  <style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

header {
  background-color: #333;
  color: white;
  padding: 20px;
  text-align: center;
}

.menu {
  padding: 20px;
}

.category {
  margin-bottom: 20px;
}

.category h2 {
  margin-top: 0;
}

.item {
  background-color: #f4f4f4;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
}

.item h3 {
  margin-top: 0;
}

.item span {
  font-weight: bold;
  display: block;
  margin-top: 10px;
}

/* Stili del modal */
/* Stili del modal */
.modal {
  display: none;
  position: fixed;
  z-index: 100;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  overflow: auto;
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  display: block;
  max-width: 80%;
  max-height: 80%;
  position: relative;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.close {
  color: #fff;
  font-size: 40px;
  font-weight: bold;
  position: absolute;
  top: 10px;
  right: 25px;
  cursor: pointer;
}

  </style>
  
</head>
<body>
 
  <header>
    <h1>Menu del Ristorante</h1>
  </header>
  
  <section class="menu">
    <?php
      $i = 0;
      $a = 0;
      $b = 0;
      $c = 0;
      $d = 0;
      $e = 0;
      if(is_array($fetchData)){      
      foreach($fetchData as $data){
        if ($data['sezione'] == 'Antipasti') {
          $array['Antipasti'][$i] = $data;
          $i++;
        }
        if ($data['sezione'] == 'Primi') {
          $array['Primi'][$a] = $data;
          $a++;
        }
        if ($data['sezione'] == 'Secondi') {
          $array['Secondi'][$b] = $data;
          $b++;
        }
        if ($data['sezione'] == 'Dolci') {
          $array['Dolci'][$c] = $data;
          $c++;
        }
        if ($data['sezione'] == 'Vini') {
          $array['Vini'][$d] = $data;
          $d++;
        }
        if ($data['sezione'] == 'Bibite') {
          $array['Bibite'][$e] = $data;
          $e++;
        }
        
      }
    }
      /*echo "<pre>";
      print_r($array);
      echo "</pre>";*/
    ?>
    
    <div class="category">
    <?php
      if (!empty($array['Antipasti'])) {
      ?> 
      <h2>Antipasti</h2>
      <?php
        for ($i = 0; $i < count($array['Antipasti']); $i++) {
      ?>
      <div class="item" onclick="showImage('<?php echo $array['Antipasti'][$i]['percorso'];?>')">
        <h3><?php echo $array['Antipasti'][$i]['nome'];?></h3>
        <p><?php echo $array['Antipasti'][$i]['descrizione'];?></p>
        <span>Prezzo: <?php echo $array['Antipasti'][$i]['prezzo'];?>$</span>
      </div>
      <?php }?>
    </div>
    <?php }?>

    <div class="category">
    <?php
      if (!empty($array['Primi'])) {
      ?> 
      <h2>Primi</h2>
      <?php
        for ($i = 0; $i < count($array['Primi']); $i++) {
      ?>
      <div class="item" onclick="showImage('<?php echo $array['Primi'][$i]['percorso'];?>')">
        <h3><?php echo $array['Primi'][$i]['nome'];?></h3>
        <p><?php echo $array['Primi'][$i]['descrizione'];?></p>
        <span>Prezzo: <?php echo $array['Primi'][$i]['prezzo'];?>$</span>
      </div>
      <?php }?>
    </div>
    <?php }?>
      <?php
      if (!empty($array['Secondi'])) {
      ?>
    <div class="category">
      <h2>Secondi</h2>
      <?php
        for ($i = 0; $i < count($array['Secondi']); $i++) {
      ?>
      <div class="item" onclick="showImage('<?php echo $array['Secondi'][$i]['percorso'];?>')">
        <h3><?php echo $array['Secondi'][$i]['nome'];?></h3>
        <p><?php echo $array['Secondi'][$i]['descrizione'];?></p>
        <span>Prezzo: <?php echo $array['Secondi'][$i]['prezzo'];?>$</span>
      </div>
      <?php }?>
    </div>
    <?php }?>
    <?php
      if (!empty($array['Dolci'])) {
      ?>       
    <div class="category">
      <h2>Dessert</h2>
      <?php
        for ($i = 0; $i < count($array['Dolci']); $i++) {
      ?>
      <div class="item" onclick="showImage('<?php echo $array['Dolci'][$i]['percorso'];?>')">
        <h3><?php echo $array['Dolci'][$i]['nome'];?></h3>
        <p><?php echo $array['Dolci'][$i]['descrizione'];?></p>
        <span>Prezzo: <?php echo $array['Dolci'][$i]['prezzo'];?>$</span>
      </div>
      <?php }?>
    </div>
    <?php }?>
    <?php
      if (!empty($array['Vini'])) {
      ?> 
    <div class="category">
      <h2>Vini</h2>
      <?php
        for ($i = 0; $i < count($array['Vini']); $i++) {
      ?>
      <div class="item" onclick="showImage('<?php echo $array['Vini'][$i]['percorso'];?>')">
        <h3><?php echo $array['Vini'][$i]['nome'];?></h3>
        <p><?php echo $array['Vini'][$i]['descrizione'];?></p>
        <span>Prezzo: <?php echo $array['Vini'][$i]['prezzo'];?>$</span>
      </div>
      <?php }?>
    </div>
    <?php }?>
    <?php
      if (!empty($array['Bibite'])) {
      ?> 
    <div class="category">
      <h2>Bibite</h2>
      <?php
        for ($i = 0; $i < count($array['Bibite']); $i++) {
      ?>
      <div class="item" onclick="showImage('<?php echo $array['Bibite'][$i]['percorso'];?>')">
        <h3><?php echo $array['Bibite'][$i]['nome'];?></h3>
        <p><?php echo $array['Bibite'][$i]['descrizione'];?></p>
        <span>Prezzo: <?php echo $array['Bibite'][$i]['prezzo'];?>$</span>
      </div>
      <?php }?>
    </div>
    <?php }?>
  </section>
  <div id="modal" class="modal">
    <span class="close" onclick="closeImage()">&times;</span>
    <img class="modal-content" id="modalImg">
  </div>
  <script>
    function showImage(imageUrl) {
        var modal = document.getElementById("modal");
        var modalImg = document.getElementById("modalImg");
        modal.style.display = "block";
        modalImg.src = imageUrl;
    }

    function closeImage() {
        var modal = document.getElementById("modal");
        modal.style.display = "none";
    }
    document.addEventListener("DOMContentLoaded", function() {
        var modal = document.getElementById("modal");
        modal.style.display = "none";
    });
  </script>
</body>
</html>






