<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>

<?php

$db= $conn;
$tableName="menu";
if(isset($_GET['edit'])){
$id = validate($_GET['edit']);
$condition= ['id' =>$id];
$columns = ['id', 'sezione','nome', 'percorso', 'descrizione', 'prezzo'];
$editData = edit_data($db, $tableName, $columns, $condition);
}
function edit_data($db, $tableName, $columns, $condition){
if(empty($db)){
 $msg= "Database connection error";
}elseif (empty($columns) || !is_array($columns)) {
  $msg="columns Name must be defined in an indexed array";
}elseif (!is_array($condition)) {
  $msg= "Condition data must be an associative array";
}
elseif(empty($tableName)){
  $msg= "Table Name is empty";
}else{
$columnName = implode(", ", $columns);
    $conditionData='';
    $i=0;
    foreach($condition as $index => $data){
        $and = ($i > 0)?' AND ':'';
         $conditionData .= $and.$index." = "."'".$data."'";
         $i++;
    }
$query = "SELECT ".$columnName." FROM $tableName";
$query .= " WHERE ".$conditionData;
$result = $db->query($query);
$row= $result->fetch_assoc();
return $row;
if($row== true){
  
 if ($result->num_rows > 0) {
    $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    $msg= $row;
    
 } else {
    $msg= "No Data Found";
  
 }
}else{
  $msg= mysqli_error($db);
}
}
return $msg;
}
// update data
extract($_POST);
if(isset($update) && isset($_GET['edit'])){
    $columns = ['id', 'sezione','nome', 'percorso', 'descrizione', 'prezzo'];
$updateDate = date("Y-m-d H:i:s");
$inputData = [
'sezione' => validate($sezione) ?? "",
'nome'   => validate($nome) ?? "",
'descrizione'   => validate($descrizione) ?? "",
'prezzo'   => validate($prezzo) ?? "",
'created_at' => $updateDate ?? ""
];
$id = validate($_GET['edit']);
$condition= ['id' =>$id];
$result= update_data($db, $tableName, $inputData, $condition);
header("location:form_table.php");
}
function update_data($db, $tableName, $inputData, $condition){
 $data = implode(" ",$inputData);
if(empty($db)){
 $msg= "Database connection error";
}elseif(empty($tableName)){
  $msg= "Table Name is empty";
}elseif(trim( $data ) == ""){
  $msg= "Empty Data not allowed to update";
}elseif(!is_array($inputData) && !is_array($condition)){
  $msg= "Input data & condition must be in array"; 
}else{
// dynamic column & input value
    $cv=0;
    $columnsAndValue='';
    foreach ($inputData as $index => $data) {
      $comma= ($cv>0)?', ':'';
      $columnsAndValue .= $comma.$index." = "."'".$data."'";
    $cv++;
    }
   
// dynamic condition       
    $conditionData='';
    $c=0;
    foreach($condition as $index => $data){
        $and = ($c>0)?', ':'';
        $conditionData .= $and.$index." = "."'".$data."'";
        $c++;
    }
// update query        
    $query   =  "UPDATE ".$tableName;
    $query  .= " SET ".$columnsAndValue;
    $query  .= " WHERE ".$conditionData;
    $execute= $db->query($query);
   
   if($execute=== true){
      $msg= "Data was updated successfully";
  }else{
      $msg= $query;
  }
}
 return $msg;
}
 function validate($value) {
  $value = trim($value);
  $value = stripslashes($value);
  $value = htmlspecialchars($value);
  return $value;
 }
?>

<?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $sezione = mysqli_real_escape_string($conn, $_POST['sezione']);
        $nome = mysqli_real_escape_string($conn, $_POST['nome']);
        $descrizione = mysqli_real_escape_string($conn, $_POST['descrizione']);
        $prezzo = mysqli_real_escape_string($conn, $_POST['prezzo']);
        if (!empty($_POST['file'])) {
          if ($_FILES["file"]["error"] == UPLOAD_ERR_OK) {
            // Percorso della cartella in cui salvare il file
            $uploadDirectory = "image/";

            // Crea la cartella se non esiste
            if (!file_exists($uploadDirectory)) {
                mkdir($uploadDirectory, 0777, true);
            }

                // Nome del file
                $nomeFile = mysqli_real_escape_string($conn, $_FILES["file"]["name"]);
                //$tmp = explode(".", $nomeFile);
                //$tipo = $tmp[1];
                $size = mysqli_real_escape_string($conn, $_FILES["file"]["size"]);
                /*echo $size;
                echo "           ";*/

                // Percorso completo del file
                $targetPath = $uploadDirectory . $nomeFile;

                // Sposta il file dalla posizione temporanea alla cartella di destinazione
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetPath)) {
                    echo "Il file $nomeFile è stato caricato con successo.";
                } else {
                    echo "Si è verificato un errore durante il caricamento del immagine.";
                }
            } else {
                echo "Si è verificato un errore durante l'upload del immagine.";
            }
            $query = "UPDATE menu SET descrizione = '$descrizione', nome = '$nome', percorso = '$targetPath', sezione = '$sezione', prezzo = '$prezzo' WHERE id= $id";
        } else {
          $query = "UPDATE menu SET descrizione = '$descrizione', nome = '$nome', sezione = '$sezione', prezzo = '$prezzo' WHERE id= $id";
        }
        
        if ($conn->query($query) === TRUE) {
            echo "Dati inseriti con successo nel database";
            header('Location:menu_table.php');
            die();
        } else {
            echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
        }
    }
?>



<?php
$db = $conn;
$tableName = "menu";
$columns = ['id', 'sezione','nome', 'percorso', 'descrizione', 'prezzo'];

$fetchData = fetch_data($db, $tableName, $columns);

function fetch_data ($db, $tableName, $columns) {
 if(empty($db)){
  $msg = "Database connection error";
 }elseif (empty($columns) || !is_array($columns)) {
  $msg = "columns Name must be defined in an indexed array";
 }elseif(empty($tableName)){
   $msg = "Table Name is empty";
}else{
$columnName = implode(", ", $columns);
$query = "SELECT ".$columnName." FROM $tableName"." ORDER BY id DESC";
$result = $db->query($query);

if($result == true){ 
 if ($result->num_rows > 0) {
    $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    $msg= $row;
 } else {
    $msg= "No Data Found"; 
 }
}else{
  $msg= mysqli_error($db);
}
}
return $msg;
}
?>





