<?php
require 'developers_menu.php';
?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label, input, textarea {
            display: block;
            margin-bottom: 10px;
            width: 100%;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        
    </style>

    
    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>
  <body>
    
    <p><?php echo !empty($result)? $result:''; ?></p>

    <form action="developers_menu.php" method="post" enctype="multipart/form-data">
    <h2 style="text-align: center;">Aggiornamento dati</h2>
        <input type="hidden" name="id" value="<?php echo $_GET['edit']; ?>">
        
        <label for="sezione">Seleziona la portata:</label>
        <select id="sezione" name="sezione">
            <option value="<?php echo $editData['sezione']??''; ?>" Selected><?php echo $editData['sezione']??''; ?></option>
            <option value="Antipasti">Antipasti</option>
            <option value="Primi">Primi</option>
            <option value="Secondi">Secondi</option>
            <option value="Dolci">Dolci</option>
            <option value="Vini">Vini</option>
            <option value="Bibite">Bibite</option>
        </select>

        <label for="nome">Nome piatto:</label>
        <input type="text" id="nome" name="nome" value="<?php echo $editData['nome']??''; ?>">
       
        <label for="descrizione">Descrizione:</label>
        <input type="text" id="descrizione" name="descrizione"  value="<?php echo $editData['descrizione']??''; ?>">

        <label for="file">Seleziona un immagine:</label>
        <input type="file" name="file" id="file">

        <label for="prezzo">Inserire il prezzo:</label>
        <input type="number" id="prezzo" name="prezzo" step="0.01" value="<?php echo $editData['prezzo']??''; ?>">
        

        <button type="submit" value="Invio" class="btn btn-primary">Save</button>
    </form>
   
   

  </body>
</html>
