<?php
require 'developers_menu.php';
?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Tabella menu</title>
  <!--Bootstrap-->
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/headers/">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <style>
    body {
    margin: 1px;
    padding: 1px;
  }
  .container {
        max-width: 600px;
        margin: 50px auto;
        text-align: center;
      }

      .options {
        display: flex;
        justify-content: space-between;
      }

      .option {
        display: inline-block;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s;
      }

      .option:hover {
        background-color: #0257d5;
      }     
      
</style>
    </head>
  <body>
    
<div>
    <?php echo $deleteMsg??''; ?>
      <table class="table table-striped table-hover">
       <thead><tr><th scope="col">Id</th>
         <th scope="col">Portata</th>
         <th scope="col">Nome piatto</th>
         <th scope="col">Descrizione</th>
         <th scope="col">Immagine</th>
         <th scope="col">Prezzo</th>
         <th scope="col">Action</th>
    </thead>
    <tbody>
  <?php
      if(is_array($fetchData)){      
      $sn=1;
      foreach($fetchData as $data){
        $temp = explode("/", $data['percorso']);
        $array['Nome'] = $temp[1];
    ?>
      <tr>
      <td scope="row"><?php echo $sn; ?></td>
      <td><?php echo $data['sezione']??''; ?></td>
      <td><?php echo $data['nome']??''; ?></td>
      <td><?php echo $data['descrizione']??''; ?></td>
      <td><?php echo '<a class="black" href="image/' . $array['Nome'] . '" target="_blank">Download</a>';?></td>
      <td><?php echo $data['prezzo']??''; ?></td>
      <td ><a href="form_table.php?edit=<?php echo $data['id']; ?>" >Modifica</a>
      <a href="delete_menu.php?edit=<?php echo $data['id']; ?>" >Elimina</a></td>
    </tr>
     <?php
      $sn++;}}else{ ?>
      <tr>
        <td colspan="8">
    <?php echo $fetchData; ?>
    </td>
        <tr>
        <?php
        }?>
        </tbody>
        </table>  
    </div>

    <div class="container">
        <div class="options">
          <a href="../menu.php" class="option">Indietro</a>
          <a href="inserimento_menu.php" class="option">Inserimento</a>
        </div>
      </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.2/dist/chart.umd.js" integrity="sha384-eI7PSr3L1XLISH8JdDII5YN/njoSsxfbrkCTnJrzXt+ENP5MOVBxD+l6sEG4zoLp" crossorigin="anonymous"></script><script src="script.js"></script>
  
  </body>
</html>
<!---->
