<?php
session_start();
require '../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
  header('Location:../login.php');
  die();
}
require '../connection.php';
?> 
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        
        if (!empty($_GET["dato"])) {
        //$numeroGiorni <= 0 && $array[$i]['Stato'] != "pagata" 
        $dato = mysqli_real_escape_string($conn,  $_GET["dato"]); 
        $id = mysqli_real_escape_string($conn,  $_GET["id"]); 
        $option = mysqli_real_escape_string($conn,  $_GET["option"]); 
          echo $dato . $option . $id;
        $sql = "UPDATE spese SET stato = '$option', metodo = '$dato' WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
          echo "Dati inseriti con successo nel database";
        } else {
            echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
        }
                    
      
                            // Esegui la query SQL
        header('Location:fatture.php');
        die();
        } else {
          echo "Nessun valore inserito";
        }            
        header('Location:fatture.php');
        die();
    } 
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //$numeroGiorni <= 0 && $array[$i]['Stato'] != "pagata" 
        $option = mysqli_real_escape_string($conn,  $_POST["option"]);
        $id = mysqli_real_escape_string($conn, $_POST["id"]);
       // echo $id . $option;
        ?>
    <?php
    if ($option == "pagata") {
    ?>
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta name="description" content="nothing">
            <meta name="author" content="anonymous">
            <style>
              body {
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  height: 100vh;
                  margin: 0;
              }
              form {
                  width: 300px; /* Adjust the width as needed */
                  padding: 20px;
                  border: 1px solid #ccc;
                  border-radius: 5px;
                  background-color: #f9f9f9;
              }
              input[type="text"] {
                  width: 100%;
                  padding: 8px;
                  margin: 6px 0;
                  box-sizing: border-box;
                  border: 1px solid #ccc;
                  border-radius: 4px;
              }
              input[type="submit"] {
                  width: 100%;
                  background-color: #0d6efd;
                  color: white;
                  padding: 10px 20px;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
              }
              input[type="submit"]:hover {
                  background-color: #45a049;
              }
          </style>
          </head>
          <body>
              <form action="ricezione_fatture.php" method="get">
                <label for="dato">Inserisci il metodo di pagamento:</label><br>
                <input type="text" id="dato" name="dato" required><br><br>
                <input type="hidden" id="campoNascosto" name="option" value="<?php echo $option;?>">
                <input type="hidden" id="campoNascosto" name="id" value="<?php echo $id;?>">
                <input type="submit" value="Invia">
              </form>
          </body>
        </html>

        <?php
          } else {
        ?>

    <?php
        
        $sql = "SELECT scadenza, dataIns FROM spese WHERE id = '$id'";
        $result = $conn->query($sql);

      // Verifica se ci sono risultati
      if ($result->num_rows > 0) {
          // Itera sui risultati e salvali nell'array
          while($row = $result->fetch_assoc()) {
              $dataIns = $row["dataIns"];
              $scadenza = $row["scadenza"];
          }
          // Ora $clienti contiene i nomi dei clienti di Roma
      } else {
          echo "Nessun risultato trovato";
      }

        $dataOdierna = new DateTime($dataIns);
        $dataOdiernaCopia = clone $dataOdierna;

        $dataFutura = $dataOdiernaCopia->add(new DateInterval("P{$scadenza}D"));
            
        $dataFormattata = $dataFutura->format('d-m-Y');
        $dataOggi = new DateTime();
        $differenza = $dataFutura->diff($dataOggi);
          
        $numeroGiorni = $differenza->days;
        if ($dataFutura < $dataOggi) {
          $numeroGiorni = -$numeroGiorni;
        }



        echo $option;
        if (!empty($option) && !empty($id)) {
          if ($numeroGiorni > 7 && $option == "scaduta") {
            $option = "niente";
            $sql = "UPDATE spese SET stato = '$option', metodo = '' WHERE id = $id";
            if ($conn->query($sql) === TRUE) {
              //echo "Dati inseriti con successo nel database";
          } else {
              //echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
          }
          } elseif($numeroGiorni <= 7 && $option == "niente") {
            
          } else {
            $sql = "UPDATE spese SET stato = '$option', metodo = '' WHERE id = $id";
            if ($conn->query($sql) === TRUE) {
              //echo "Dati inseriti con successo nel database";
          } else {
              //echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
          }
          }
         
      
                            // Esegui la query SQL
        header('Location:fatture.php');
        die();
        } else {
          echo "Nessun valore inserito";
          echo "<p class=\"red\">Errore</p>";
          header('Location:fatture.php');
          die();
        }            
        header('Location:fatture.php');
        die();
    } 
  } else {
    header('Location:fatture.php');
    die();
  }
?>
