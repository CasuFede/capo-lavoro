<?php
session_start();
require '../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
  header('Location:../login.php');
  die();
}
require '../connection.php';
?>  
<!DOCTYPE html>
<html>
    <head>
        <title>Ricezione dati</title>
        <meta charset="UTF-8" />
    </head>
    
    <body>
        
        
        <h1>Ricezione dati per grafici</h1>
        <?php
        $go = true;
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            if (empty($_POST["date"])) {
                $go = false;
            } else {
                $date = mysqli_real_escape_string($conn, $_POST["date"]);
            }
            //echo $date;
            if ($go == false) {
                echo "<p class=\"red\">Errore</p>";
                header('Location:grafici.php');
                die();
            } else {
                /*mese*/
                $inputWeek = $date; 
                list($anno, $settimana) = explode("-W", $inputWeek);
                $primoGiornoSettimana = date("Y-m-d", strtotime($anno . "W" . sprintf('%02d', $settimana) . '1'));
                $nomeMese = date("F", strtotime($primoGiornoSettimana));

                /*Stampa mese*/
                //echo "<br />Il mese corrispondente è: " . $nomeMese;

                /*giorni*/
                list($anno, $settimana) = explode("-W", $inputWeek);
                $primoGiornoSettimana = date("Y-m-d", strtotime($anno . "W" . sprintf('%02d', $settimana) . '1'));
                $giorniSettimana = [];
                for ($i = 0; $i < 7; $i++) {
                    $giorniSettimana[] = date("l, d-m-Y  ", strtotime($primoGiornoSettimana . " +$i days"));
                    $dataGiorni[] = date("d-m-Y", strtotime($primoGiornoSettimana . " +$i days"));
                }

                /*stampa giorno e data*/
                //echo "<br />I giorni della settimana sono:\n" . implode("\n", $giorniSettimana);
                /*stampa date*/
                /*echo "<pre>";
                print_r($dataGiorni);
                echo "</pre>";*/
                
                $first = $dataGiorni[0];
                $last = $dataGiorni[6];
                $query = "SELECT * FROM date_data WHERE (data_ >= '$first' AND data_ <= '$last')";
                

                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    // Creazione della tabella HTML
                    /*echo "<table border='1'>";
                    echo "<tr><th>Colonna1</th><th>Colonna2</th><th>Colonna3</th></tr>";

                    $i = 0;*/

                    /*while ($row = $result->fetch_assoc()) {

                        $data["Id, $i"] = $row['id'];
                        $data["Data_, $i"] = $row['data_'];
                        $data["Information, $i"] = $row['information'];
                        $data["InfoType, $i"] = $row['infoType'];
                        $i++;
                    }
                    echo "<pre>";
                    print_r($data);
                    echo "</pre>";*/
                    
                    /*while ($row = $result->fetch_assoc()) {
                        echo "<script>";
                        echo "console.log('->', ".json_encode($row['id']).");";
                        echo "console.log('->', ".json_encode($row['data_']).");";
                        echo "console.log('->', ".json_encode($row['information']).");";
                        echo "console.log('->', ".json_encode($row['infoType']).");";
                        echo "</script>";
                    }*/
                    $i = 0;
                    while ($row = $result->fetch_assoc()) {
                      $array[$i] = $row['data_'];
                      $i++;
                    }
                    echo "<pre>";
                    print_r($array);
                    echo "</pre>";
                    // Stampa dei dati nella tabella
                    /*while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row['id'] . "</td><td>" . $row['data_'] . "</td><td>" . $row['information'] . "</td></tr>";
                    }
                    echo "</table>";*/
                   
                } else {
                    echo "risultato non trovato";
                }
                /*header('Location:grafici.php');
                $_SESSION['ricezione'] = "All good";*/
                
            }
        } else {
            echo "<p class=\"red\">Errore</p>";
            header('Location:invio.php');
            die();
        }
        ?>
        <?php include "../close_connection.php"; ?>
    </body>
</html>

