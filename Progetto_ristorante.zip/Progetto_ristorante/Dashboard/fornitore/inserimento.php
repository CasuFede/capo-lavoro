<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label, input, select {
            display: block;
            margin-bottom: 10px;
            width: 98%;
        }
        select {
            width: 100%;
        }
        input[type="submit"] {
            width: 101%;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        .container1 {
        margin: auto;
        display: flex;
        width: 100%;
      }

      .myInput {
        width: 50%;
    }


    </style>

  </head>
  <body>
    <?php
    session_start();
    require '../../functions.php';
    if (!isUserLoggedIn() || getUserEmail() != "Capo") {
        header('Location:../../login.php');
        die();
    }
    require '../../connection.php';
    ?>  
    
    <form name="dati" id="dati" action="ricezione.php" method="post">
    <h2 style="text-align: center;">Dati del fornitore</h2>
        
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>
       
        <label for="descrizione">Numero:</label>
        <input type="tel" name="telefono" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" placeholder="000-000-0000" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="ingrediente">Ingrediente:</label>
        <input type="text" name="ingrediente" id="file" required>
    <p></p>
        <div class="container1">

            <input class="myInput" type="number" min="0" name="prezzo" id="prezzo" step="0.01" placeholder="costo" required>

            <select class="myInput" id="selectOption" name="misura" required>
            <optgroup label="Liquidi">
                <option value="L">Litri</option>
                <option value="ml">MilliLitri</option>
            </optgroup>
            <optgroup label="Solidi">
                <option value="Kg">KiloGrammi</option>
                <option value="gr">Grammi</option>
            </optgroup>
            </select>
    </div>     
        <input type="submit" value="Invia">
    </form>
   

  </body>
</html>