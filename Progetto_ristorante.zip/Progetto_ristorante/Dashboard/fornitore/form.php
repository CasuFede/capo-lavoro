<?php
require 'developers.php';
?> 
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label, input, textarea {
            display: block;
            margin-bottom: 10px;
            width: 100%;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        
    </style>

    
    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>
  <body>
     
    <p><?php echo !empty($result)? $result:''; ?></p>

    <form action="developers.php" method="post">
    <h2 style="text-align: center;">Aggiornamento dati</h2>
        <input type="hidden" name="id" value="<?php echo $_GET['edit']; ?>">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" value="<?php echo $editData['nome']??''; ?>">
       
        <label for="descrizione">Numero:</label>
        <input type="tel" name="telefono" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" value="<?php echo $editData['telefono']??''; ?>">

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $editData['email']??''; ?>">

        <label for="ingrediente">Ingrediente:</label>
        <input type="text" name="ingrediente" id="file" value="<?php echo $editData['ingrediente']??''; ?>">

        <div class="container1">

            <input class="myInput" type="number" min="0" name="prezzo" id="prezzo" step="0.01" value="<?php echo $editData['prezzo']??''; ?>">

            <select class="myInput" id="selectOption" name="misura">
            <option value="<?php echo $editData['misura']??''; ?>" Selected><?php echo $editData['misura']??''; ?></option>
            <optgroup label="Liquidi">
                <option value="L">Litri</option>
                <option value="ml">MilliLitri</option>
            </optgroup>
            <optgroup label="Solidi">
                <option value="Kg">KiloGrammi</option>
                <option value="gr">Grammi</option>
            </optgroup>
            </select>
        </div>
        <button type="submit" value="Invio" class="btn btn-primary">Save</button>
    </form>
   
   

  </body>
</html>


