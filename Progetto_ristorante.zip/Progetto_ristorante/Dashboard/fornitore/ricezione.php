<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?> 
<!DOCTYPE html>
<html>
    <head>
        <title>Ricezione dati</title>
        <meta charset="UTF-8" />
    </head>
    <body>
         
        <h1>Ricezione dati</h1>
        <?php
        $p1 = true;
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
           
            if (empty($_POST["nome"])) {
                $p1 = false;
            } else {
                $nome = $_POST["nome"];
            }
            if (empty($_POST["telefono"])) {
                $p1 = false;
            } else {
                $telefono = $_POST["telefono"];
            }
            if (empty($_POST["email"])) {
                $p1 = false;
            } else {
                $email = $_POST["email"];
            }  
            if (empty($_POST["ingrediente"])) {
                $p1 = false;
            } else {
                $ingrediente = $_POST["ingrediente"];
            }  
            if (empty($_POST["misura"])) {
                $p1 = false;
            } else {
                $misura = $_POST["misura"];
            }  
            if (empty($_POST["prezzo"])) {
                $p1 = false;
            } else {
                $prezzo = $_POST["prezzo"];
            }  
            if ($p1 != false) { 
                $query = "INSERT INTO fornitore (nome, telefono, email, ingrediente, prezzo, misura)
                VALUES('$nome', '$telefono', '$email', '$ingrediente', '$prezzo', '$misura')";
                if($conn->query($query) === TRUE){
                    header('Location:tabella.php');
                    die();
                }else{
                    echo "Inserimento errore".$conn->error;
                }
            } else {
                echo "<p class=\"red\">Errore</p>";
                /*header('Location:inserimento.php');
                die();*/
            }
            
        } else {
            echo "<p class=\"red\">fefefe</p>";
            /*header('Location:inserimento.php');
            die();*/
        }
        ?>
        <?php include "../../close_connection.php"; ?>
    </body>
</html>