<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>  
        <h1>Ricezione dati</h1>
        <?php
        $p1 = true;
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            if (empty($_POST["id"])) {
                $p1 = false;
            } else {
                $id = $_POST["id"];
            }
            if (empty($_POST["numero"])) {
                $p1 = false;
            } else {
                $numero = $_POST["numero"];
            }  
            $max = 0;
            $query = "SELECT * FROM magazzino";
            $result = $conn->query($query);
            if ($result->num_rows > 0) {     
                while ($row = $result->fetch_assoc()) {
                    if ($id == $row['id']) {
                        $max = $row['quantita'];
                    }
                }
                    $quantita = $max + $numero;
                    if ($p1 != false) { 
                        $query = "UPDATE magazzino SET quantita = '$quantita' WHERE id= $id";
                        if($conn->query($query) === TRUE){
                            header('Location:tabella.php');
                            die();
                        }else{
                            echo "Inserimento errore".$conn->error;
                        }
                    } else {
                        echo "<p class=\"red\">Errore</p>";
                        header('Location:tabella.php');
                        $_SESSION['message4'] = "Errore";
                        die();
                    }
                
            }    
            
            
            
        } else {
            echo "<p class=\"red\">Errore</p>";
            header('Location:tabella.php');
            $_SESSION['message4'] = "Errore";
            die();
        }
        include "../../close_connection.php";
        ?>