<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label, input, textarea, select {
            display: block;
            margin-bottom: 10px;
            width: 100%;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>

  </head>
  <body>
    <?php
    // Query per ottenere i dati dal database
    $sql = "SELECT id, nome FROM fornitore";
    $result = $conn->query($sql);
    ?>
    
    <form name="dati" id="dati" action="ricezione.php" method="post" >
        <h2 style="text-align: center;">Inserisci i dati</h2>

        <label for="descrizione">Descrizione:</label>
        <input type="text" id="descrizione" name="descrizione">

        <label for="quantita">Inserisci la quantità</label>
        <input type="number" name="quantita" id="quantita" step="1" required>

        <label for="scelta">Seleziona fornitore:</label>
        <select name="scelta" id="scelta">
            <?php
            // Ciclo attraverso i risultati della query
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    // Stampare le opzioni del menu a discesa utilizzando i dati ottenuti dal database
                    echo "<option value='" . $row['id'] . "'>" . $row['nome'] . "</option>";
                }
            } else {
                echo "<option value=''>Nessuna opzione disponibile</option>";
            }
            ?>
        </select>
        
        <input type="submit" value="Invia">
    </form>
   

  </body>
</html>
