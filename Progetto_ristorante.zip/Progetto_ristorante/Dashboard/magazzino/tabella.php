<?php
require 'developers.php';
?> 
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Tabella magazzino</title>
  <!--Bootstrap-->
  <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/headers/">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <style>
    body {
        margin: 1px;
        padding: 1px;
    }
    .piccolo{
      width: 100px;
    }
.container {
  display: flex;
  align-items: center; /* per allineare verticalmente al centro */
}



.input-number {
  width: 60px;
  height: 25px;
}


#button1{
  display: inline-block;
  padding: 0.9px 1.8px;
  background-color: #008CBA;
  color: #fff;
  border: none;
  border-top-right-radius: 10px; /* Arrotonda solo l'angolo in alto a sinistra */
  border-bottom-right-radius: 10px; /* Arrotonda solo l'angolo in basso a sinistra */
  cursor: pointer;
  transition: background-color 0.3s ease;
  /* Imposta la larghezza del bottone in base al contenuto */
  width: auto;
}
#button2 {
  display: inline-block;
  padding: 0.9px 1.8px;
  background-color: #008CBA;
  color: #fff;
  border: none;
  border-top-right-radius: 10px; /* Arrotonda solo l'angolo in alto a sinistra */
  border-bottom-right-radius: 10px; /* Arrotonda solo l'angolo in basso a sinistra */
  cursor: pointer;
  transition: background-color 0.3s ease;
  /* Imposta la larghezza del bottone in base al contenuto */
  width: auto;
}

.red {
  background-color: red !important;
}
#myInput {
  background-image: url('/css/searchicon.png'); /* Add a search icon to input */
}
.container1 {
        max-width: 600px;
        margin: 50px auto;
        text-align: center;
      }

      .options1 {
        display: flex;
        justify-content: space-between;
      }

      .option1 {
        display: inline-block;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s;
      }

      .option1:hover {
        background-color: #0257d5;
      } 
      #myInput {
        margin: 5px;
  border: 2px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  outline: none;
  transition: border-color 0.3s ease-in-out;
}

#myInput:focus {
  border-color: dodgerblue;
}

</style>

  <body>
  
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names..">

<div>
    <?php echo $deleteMsg??''; ?>
      <table class="table table-striped table-hover" id="myTable">
       <thead><tr><!--<th scope="col">Id</th>-->
         <th scope="col">Quantita</th>
         <th scope="col">Descrizione</th>
         <th scope="col">Fornitore</th>
         <th scope="col">Incremento</th>
         <th scope="col">Decremento</th>
         <th scope="col">Action</th>
    </thead>
    <tbody>
  <?php
      if(is_array($fetchData)){      
      //$sn=1;
      foreach($fetchData as $data){
        $cod = $data['codFornitore'];
        $sql = "SELECT nome FROM fornitore WHERE id = '$cod'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            // Output dei dati di ogni riga
            while($row = mysqli_fetch_assoc($result)) {
              $nome = $row["nome"];
            }
        } else {
            echo "0 risultati";
        }
    ?>
      <tr>
        <?php
        if ($data['quantita'] < 10) {
          $color = 'red';
        } else {
          $color = '';
        }
        ?>
        <!----->
      <!--<td scope="row"><?php //echo $sn; ?></td>-->
      <td class="<?php echo $color;?>"><?php echo $data['quantita']??''; ?></td>
      <td class="<?php echo $color;?>"><?php echo $data['descrizione']??''; ?></td>
      <td><a href="../fornitore/tabella.php?edit=<?php echo $data['codFornitore']; ?>"><?php echo $nome; ?></a></td>
      <td class="piccolo">  
        <form action="incremento.php" method="POST">
            <div class="container">
                <input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>">
                <input type="number" class="input-number" name="numero" min="1" step="1">
                <button type="submit" value="Submit" id="button1" >invio</button>
            </div>
          </form>
      </td>
      <td class="piccolo">
        <form action="decremento.php" method="POST">
          <div class="container">
              <input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>">
              <input type="number" class="input-number" name="numero" min="1" step="1">
              <button type="submit" value="Submit" id="button2" >invio</button>
          </div>
        </form>
      </td>
      <td><a href="delete.php?edit=<?php echo $data['id']; ?>">Delete</a></td>
  
      </td>
    </tr>
     <?php
      //$sn++;
      }}else{ ?>
      <tr>
        <td colspan="8">
    <?php echo $fetchData; ?>
    </td>
        <tr>
        <?php
        }?>
        </tbody>
        </table>  
    </div>
    <?php
        if (!empty($_SESSION['message4'])) { ?>
        <script>
            window.alert('<?= $_SESSION['message4'] ?>');
        </script>
        <?php
            $_SESSION['message4'] = '';
        }
        ?>
        <div class="container1">
        <div class="options1">
          <a href="../magazzino.php" class="option1">Indietro</a>
          <a href="inserimento.php" class="option1">Inserimento</a>
        </div>
      </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.2/dist/chart.umd.js" integrity="sha384-eI7PSr3L1XLISH8JdDII5YN/njoSsxfbrkCTnJrzXt+ENP5MOVBxD+l6sEG4zoLp" crossorigin="anonymous"></script><script src="script.js"></script>
    <script>
    function myFunction() {
        // Declare variables
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable"); // Modifica questo ID in base all'ID della tua tabella
        tr = table.getElementsByTagName("tr");

        // Loop through all table rows, and hide those who don't match the search query
        for (i = 0; i < tr.length; i++) {
            // Modifica questa parte per adattarla alla tua tabella PHP
            // Estrarre la cella desiderata da ogni riga della tabella
            td = tr[i].getElementsByTagName("td")[1]; // Modifica l'indice [1] in base alla posizione della colonna che vuoi filtrare
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }
</script>

  </body>
</html>
