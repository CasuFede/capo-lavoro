
<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<?php

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $id = $_GET['edit'];
    $query = "DELETE FROM magazzino WHERE id = $id";
    if ($conn->query($query) === TRUE) {
        echo "Dati eliminati con successo nel database";
        header('Location:tabella.php');
        die();
    } else {
        echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
    }

}


?>