<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?> 
<!DOCTYPE html>
<html>
    <head>
        <title>Ricezione dati</title>
        <meta charset="UTF-8" />
    </head>
    <body>
         
        <h1>Ricezione dati</h1>
        <?php
        $p1 = true;
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            if (empty($_POST["descrizione"])) {
                $descrizione = "";
            } else {
                $descrizione = mysqli_real_escape_string($conn, $_POST["descrizione"]);
            }
            if (empty($_POST["quantita"])) {
                $p1 = false;
            } else {
                $quantita = mysqli_real_escape_string($conn, $_POST["quantita"]);
            }  
            if (empty($_POST["scelta"])) {
                $p1 = false;
            } else {
                $scelta = mysqli_real_escape_string($conn, $_POST["scelta"]);
            } 

            if ($p1 != false) { 
                $query = "INSERT INTO magazzino (descrizione, quantita, codFornitore)
                VALUES('$descrizione', '$quantita', '$scelta')";
                if($conn->query($query) === TRUE){
                    header('Location:tabella.php');
                    die();
                }else{
                    echo "Inserimento errore".$conn->error;
                }
            } else {
                echo "<p class=\"red\">Errore</p>";
                header('Location:tabella.php');
                die();
            }
            
        } else {
            echo "<p class=\"red\">Errore</p>";
            header('Location:tabella.php');
            die();
        }
        ?>
        <?php include "../close_connection.php"; ?>
    </body>
</html>