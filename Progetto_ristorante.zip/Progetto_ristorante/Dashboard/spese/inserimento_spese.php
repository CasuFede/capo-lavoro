<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label, input, select {
            display: block;
            margin-bottom: 10px;
            width: 100%;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        
    </style>

    
    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>
  <body>
    
    
    <form name="dati" id="dati" action="ricezione_spese.php" method="post" enctype="multipart/form-data">
    <h2 style="text-align: center;">Inserisci i tuoi dati</h2>
        <label for="data">Data:</label>
        <input type="date" id="data" name="data"  required>
        
        <label for="motivazione">Motivazione:</label>
        <input type="text" id="motivazione" name="motivazione" required>
       
        <label for="importo">Importo:</label>
        <input type="number" id="importo" name="importo" step="0.01" required>

        <div class="form-group" id="inline">
            <label for="inputScadenza">Scadenza</label>
            <select name="scadenza" class="form-select" aria-label="Default select example">
                <option selected>Giorni</option>
                <option value="30">30</option>
                <option value="60">60</option>
                <option value="90">90</option>
            </select>
        </div>

        <label for="file">Seleziona una fattura:</label>
        <input type="file" name="file" id="file" required>


        <input type="submit" value="Invia">
    </form>
   

  </body>
</html>
