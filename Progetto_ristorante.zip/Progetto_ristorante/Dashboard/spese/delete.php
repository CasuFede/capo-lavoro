
<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<?php

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $id = $_GET['edit'];
    $query = "SELECT * FROM spese";
      $result = $conn->query($query);
      if ($result->num_rows > 0) {     
        while ($row = $result->fetch_assoc()) {
            if ($id == $row['id']) {
                $percorso = $row['percorso'];
            }
        }
        $cartFile = explode("/", $percorso);
        $cartella = $cartFile[0] . "/"; // Specifica il percorso alla cartella dove si trova il file
        $file_to_delete =  $cartFile[1]; // Specifica il nome del file da eliminare
        // Verifica se il file esiste nella cartella
        if (file_exists($cartella . $file_to_delete)) {
            // Elimina il file
            if (unlink($cartella . $file_to_delete)) {
                echo 'Il file è stato eliminato con successo.';
            } else {
                echo 'Si è verificato un errore durante l\'eliminazione del file.';
            }
        } else {
            echo 'Il file non esiste nella cartella specificata.';
        }
        $query = "DELETE FROM spese WHERE id = $id";
        if ($conn->query($query) === TRUE) {
            echo "Dati eliminati con successo nel database";
            header('Location:tabella.php');
            die();
        } else {
            echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
        }
    }
    
}


?>