<?php
require 'developers.php';
?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Inserimento dati</title>
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label, input, textarea {
            display: block;
            margin-bottom: 10px;
            width: 100%;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        
    </style>

    
    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>
  <body>
    
    <p><?php echo !empty($result)? $result:''; ?></p>

    <form action="developers.php" method="post">
    <h2 style="text-align: center;">Aggiornamento dati</h2>
        <input type="hidden" name="id" value="<?php echo $_GET['edit']; ?>">
        
        <label for="data">Data:</label>
        <input type="date" id="data" name="data" value="<?php echo $editData['dataIns']??''; ?>">
        
        <label for="motivazione">Motivazione:</label>
        <input type="text" id="motivazione" name="motivo" value="<?php echo $editData['motivo']??''; ?>">
       
        <label for="importo">Importo:</label>
        <input type="number" id="importo" name="importo" step="0.01" value="<?php echo $editData['importo']??''; ?>">

        <button type="submit" value="Invio" class="btn btn-primary">Save</button>
    </form>
   
   

  </body>
</html>
