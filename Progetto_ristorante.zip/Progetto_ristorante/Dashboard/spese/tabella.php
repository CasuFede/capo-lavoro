<?php
require 'developers.php';
?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Tabella modifica</title>
  <!--Bootstrap-->
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/headers/">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <style>
    body {
    margin: 1px;
    padding: 1px;
  }
  .form-inline {
    display: flex; 
    float: right;
    width: 350px;
  }

  .form-inline input[type="date"] {
    margin-right: 2px; /* Adjust spacing between inputs */
  }

  .form-inline button {
    padding: 6px 12px;
    border: none;
    border-radius: 4px;
  }
  .container {
        max-width: 600px;
        margin: 50px auto;
        text-align: center;
      }

      .options {
        display: flex;
        justify-content: space-between;
      }

      .option {
        display: inline-block;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s;
      }

      .option:hover {
        background-color: #0257d5;
      } 
</style>
  <body>
    <?php
    $tmp1 = '';
    if (!empty($_POST['date1']) && !empty($_POST['date2'])) {
      $date1 = mysqli_real_escape_string($conn, $_POST['date1']);
      $date2 = mysqli_real_escape_string($conn, $_POST['date2']);
    } else {
      $date1 = "0000-00-00";
      $date2 = "0000-00-00";
    }
    
    ?>
  <header >
    <form action="tabella.php" method="POST">
      <div class="form-inline">
        <input  type="date" value="<?php echo $date1;?>" class="form-control" name="date1" id="date1" required>
        <input type="date" value="<?php echo $date2;?>" class="form-control" name="date2" id="date2" required>
        <button type="submit" value="Submit" class="btn btn-primary">Invio</button>
      </div>
    </form> 
  </header>
  
  <main>
  <div>
      <?php echo $deleteMsg??''; ?>
      <table class="table table-striped table-hover">
        <thead><tr><th scope="col">Id</th>
          <th scope="col">Motivo</th>
          <th scope="col">Data Inserimento</th>
          <th scope="col">Fattura</th>
          <th scope="col">Importo</th>
          <th scope="col">Action</th>
      </thead>
      <tbody>
        <?php
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $date1 = mysqli_real_escape_string($conn, $_POST["date1"]);
            $date2 = mysqli_real_escape_string($conn, $_POST["date2"]);
            if ($date1 < $date2) {
              $tmp = $date1;
              $date1 = $date2;
              $date2 = $tmp;
            }
        }
        $spese = 0;
        if(is_array($fetchData)){      
          $sn=1;
          foreach($fetchData as $data){
            $temp = explode("/", $data['percorso']);
            $array['Nome'] = $temp[1];
            $prova = $data['dataIns']??'';
            if (!empty($_POST["date1"]) && !empty($_POST["date2"])) {
              
              if ($prova < $date1 && $prova > $date2) {
                $tmp1 = $data['motivo']??'';
              
              ?>
                <tr>
                  <td scope="row"><?php echo $sn; ?></td>
                  <td><?php echo $data['motivo']??''; ?></td>
                  <td><?php echo $data['dataIns']??''; ?></td>
                  <td><?php echo '<a class="black" href="fattureSpese/' . $array['Nome'] . '" target="_blank">Download</a>';?></td>
                  <td><?php echo $data['importo']??''; ?></td>
                  <td ><a href="form.php?edit=<?php echo $data['id']; ?>" >Modifica</a>
                  <a href="delete.php?edit=<?php echo $data['id']; ?>" >Elimina</a></td>
                </tr>
              <?php
                $sn++;
                $spese += $data['importo'];
              } 
            } else {
              ?>
              <tr>
                <td scope="row"><?php echo $sn; ?></td>
                <td><?php echo $data['motivo']??''; ?></td>
                <td><?php echo $data['dataIns']??''; ?></td>
                <td><?php echo '<a class="black" href="fattureSpese/' . $array['Nome'] . '" target="_blank">Download</a>';?></td>
                <td><?php echo $data['importo']??''; ?></td>
                <td ><a href="form.php?edit=<?php echo $data['id']; ?>" >Modifica</a>
                <a href="delete.php?edit=<?php echo $data['id']; ?>" >Elimina</a></td>
              </tr>
              <?php
              $spese += $data['importo'];
              $sn++;
            }
      
          }
        }else{ 
        ?>
        <tr>
          <td colspan="8">
      <?php echo $fetchData; ?>
          </td>
        <tr>
          <?php
        }
        if ($tmp1 == '' && $date1 != "0000-00-00") {
          ?>
        <tr>
          <td colspan="8">
      <?php echo "No Data Found"; ?>
          </td>
        <tr>
          <?php
        }
        ?>
          </tbody>
          </table>  
          <p>Spese totali: <?php echo $spese . "$";?></p>
    </div>
    <?php
        if (!empty($_SESSION['message2'])) { ?>
        <script>
            window.alert('<?= $_SESSION['message2'] ?>');
        </script>
        <?php
            $_SESSION['message2'] = '';
        }
        ?>
    </main>
    <div class="container">
        <div class="options">
          <a href="../spese.php" class="option">Indietro</a>
          <a href="inserimento_spese.php" class="option">Inserimento</a>
        </div>
      </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.2/dist/chart.umd.js" integrity="sha384-eI7PSr3L1XLISH8JdDII5YN/njoSsxfbrkCTnJrzXt+ENP5MOVBxD+l6sEG4zoLp" crossorigin="anonymous"></script><script src="script.js"></script>
  
  </body>
</html>
<!---->
