<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>  
<!DOCTYPE html>
<html>
    <head>
        <title>Ricezione dati</title>
        <meta charset="UTF-8" />
    </head>
    <body>
        
        <h1>Ricezione dati</h1>
        <?php
        $p1 = true;
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            if (empty($_POST["data"])) {
                $p1 = false;
            } else {
                $data = mysqli_real_escape_string($conn, $_POST["data"]);
            }
            if (empty($_POST["scadenza"])) {
                $p1 = false;
            } else {
                $scadenza = mysqli_real_escape_string($conn, $_POST["scadenza"]);
            } 
            if (empty($_POST["motivazione"])) {
                $p1 = false;
            } else {
                $motivazione = mysqli_real_escape_string($conn, $_POST["motivazione"]);
            }

            if (empty($_POST["importo"])) {
                $p1 = false;
            } else {
                $importo = mysqli_real_escape_string($conn, $_POST["importo"]);
            }  
            if (empty($_POST["file"])) {
                $p2 = false;
            } else {
                $media = mysqli_real_escape_string($conn, $_POST["file"]);
            }
            if (empty($_POST["scadenza"])) {
                $p2 = false;
            } else {
                $scadenza = mysqli_real_escape_string($conn, $_POST["scadenza"]);
            }
            // Controlla se è stato caricato un file senza errori
            if ($_FILES["file"]["error"] == UPLOAD_ERR_OK) {
                // Percorso della cartella in cui salvare il file
                $uploadDirectory = "fattureSpese/";

                // Crea la cartella se non esiste
                if (!file_exists($uploadDirectory)) {
                    mkdir($uploadDirectory, 0777, true);
                }

                // Nome del file
                $nomeFile = mysqli_real_escape_string($conn, $_FILES["file"]["name"]);
                //$tmp = explode(".", $nomeFile);
                //$tipo = $tmp[1];
                $size = mysqli_real_escape_string($conn, $_FILES["file"]["size"]);
                /*echo $size;
                echo "           ";*/

                $filename = 'variabile_spese.txt';

                // Leggi il valore corrente dalla memoria o imposta un valore di default
                $variabile = file_exists($filename) ? intval(file_get_contents($filename)) : 0;

                // Ottieni la data corrente
                //$dataCorrente = date('Y-m-d');
                // Ottieni la data dell'ultima modifica del file (se esiste)
                //$dataUltimaModifica = file_exists($filename) ? date('Y-m-d', filemtime($filename)) : null;
                
                // Percorso completo del file
                $targetPath = $uploadDirectory . $variabile . $nomeFile;

                // Cambia il valore della variabile
                $variabile++;

                // Salva il nuovo valore nel file
                file_put_contents($filename, $variabile);
                // Sposta il file dalla posizione temporanea alla cartella di destinazione
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetPath)) {
                    echo "Il file $nomeFile è stato caricato con successo.";
                } else {
                    echo "Si è verificato un errore durante il caricamento del file.";
                }
            } else {
                echo "Si è verificato un errore durante l'upload del file.";
            }


            if ($p1 != false) { 
                $query = "INSERT INTO spese (motivo, dataIns, percorso, importo, scadenza, stato)
                VALUES('$motivazione', '$data', '$targetPath', '$importo', '$scadenza', 'niente')";
                if($conn->query($query) === TRUE){
                    header('Location:tabella.php');
                    $_SESSION['message2'] = "Fattura inserita con successo";
                    die();
                }else{
                    echo "Inserimento fattura errore".$conn->error;
                }
            } else {
                echo "<p class=\"red\">Errore</p>";
                header('Location:spese.php');
                die();
            }
            
        } else {
            echo "<p class=\"red\">Errore</p>";
            header('Location:spese.php');
            die();
        }
        ?>
        <?php include "../close_connection.php"; ?>
    </body>
</html>