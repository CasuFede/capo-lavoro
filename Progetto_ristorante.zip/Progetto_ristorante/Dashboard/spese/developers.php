<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>

<?php

$db= $conn;
$tableName="spese";
if(isset($_GET['edit'])){
$id = validate($_GET['edit']);
$condition= ['id' =>$id];
$columns = ['id', 'motivo','dataIns','percorso','importo'];
$editData = edit_data($db, $tableName, $columns, $condition);
}
function edit_data($db, $tableName, $columns, $condition){
if(empty($db)){
 $msg= "Database connection error";
}elseif (empty($columns) || !is_array($columns)) {
  $msg="columns Name must be defined in an indexed array";
}elseif (!is_array($condition)) {
  $msg= "Condition data must be an associative array";
}
elseif(empty($tableName)){
  $msg= "Table Name is empty";
}else{
$columnName = implode(", ", $columns);
    $conditionData='';
    $i=0;
    foreach($condition as $index => $data){
        $and = ($i > 0)?' AND ':'';
         $conditionData .= $and.$index." = "."'".$data."'";
         $i++;
    }
$query = "SELECT ".$columnName." FROM $tableName";
$query .= " WHERE ".$conditionData;
$result = $db->query($query);
$row= $result->fetch_assoc();
return $row;
if($row== true){
  
 if ($result->num_rows > 0) {
    $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    $msg= $row;
    
 } else {
    $msg= "No Data Found";
  
 }
}else{
  $msg= mysqli_error($db);
}
}
return $msg;
}
// update data
extract($_POST);
if(isset($update) && isset($_GET['edit'])){
    $columns = ['id', 'motivo','dataIns','percorso','importo'];
$updateDate = date("Y-m-d H:i:s");
$inputData = [
'motivo' => validate($motivo) ?? "",
'dataIns'   => validate($dataIns) ?? "",
'importo'   => validate($importo) ?? "",
'created_at' => $updateDate ?? ""
];
$id = validate($_GET['edit']);
$condition= ['id' =>$id];
$result= update_data($db, $tableName, $inputData, $condition);
header("location:form.php");
}
function update_data($db, $tableName, $inputData, $condition){
 $data = implode(" ",$inputData);
if(empty($db)){
 $msg= "Database connection error";
}elseif(empty($tableName)){
  $msg= "Table Name is empty";
}elseif(trim( $data ) == ""){
  $msg= "Empty Data not allowed to update";
}elseif(!is_array($inputData) && !is_array($condition)){
  $msg= "Input data & condition must be in array"; 
}else{
// dynamic column & input value
    $cv=0;
    $columnsAndValue='';
    foreach ($inputData as $index => $data) {
      $comma= ($cv>0)?', ':'';
      $columnsAndValue .= $comma.$index." = "."'".$data."'";
    $cv++;
    }
   
// dynamic condition       
    $conditionData='';
    $c=0;
    foreach($condition as $index => $data){
        $and = ($c>0)?', ':'';
        $conditionData .= $and.$index." = "."'".$data."'";
        $c++;
    }
// update query        
    $query   =  "UPDATE ".$tableName;
    $query  .= " SET ".$columnsAndValue;
    $query  .= " WHERE ".$conditionData;
    $execute= $db->query($query);
   
   if($execute=== true){
      $msg= "Data was updated successfully";
  }else{
      $msg= $query;
  }
}
 return $msg;
}
 function validate($value) {
  $value = trim($value);
  $value = stripslashes($value);
  $value = htmlspecialchars($value);
  return $value;
 }
?>

<?php
    if ($_SERVER["REQUEST_METHOD"] === "POST" && empty($_POST['date1'])) {
        $id = $_POST['id'];
        $motivo = $_POST['motivo'];
        $dataIns = $_POST['data'];
        $importo = $_POST['importo'];
        $query = "UPDATE spese SET motivo = '$motivo', dataIns = '$dataIns', importo = '$importo' WHERE id= $id";
        if ($conn->query($query) === TRUE) {
            echo "Dati inseriti con successo nel database";
            header('Location:tabella.php');
            die();
        } else {
            echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
        }
    }
?>



<?php
$db = $conn;
$tableName = "spese";
$columns = ['id', 'motivo','dataIns','percorso','importo'];

$fetchData = fetch_data($db, $tableName, $columns);

function fetch_data ($db, $tableName, $columns) {
 if(empty($db)){
  $msg = "Database connection error";
 }elseif (empty($columns) || !is_array($columns)) {
  $msg = "columns Name must be defined in an indexed array";
 }elseif(empty($tableName)){
   $msg = "Table Name is empty";
}else{
$columnName = implode(", ", $columns);
$query = "SELECT ".$columnName." FROM $tableName"." ORDER BY id DESC";
$result = $db->query($query);

if($result == true){ 
 if ($result->num_rows > 0) {
    $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    $msg= $row;
 } else {
    $msg= "No Data Found"; 
 }
}else{
  $msg= mysqli_error($db);
}
}
return $msg;
}
?>





