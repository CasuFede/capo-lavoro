<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>Fluid &middot; </title>
  
    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic" rel="stylesheet">
    <link href="css/toolkit-light.css" rel="stylesheet">
    <link href="css/application.css" rel="stylesheet">

    <style>
        /* Stile per i grafici */
        .ex-line-graphs,
        .ex-graphs {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-bottom: 30px;
        }

        .ex-line-graph,
        .ex-graph {
            width: calc(50% - 20px);
            margin: 10px;
        }

        /* Stile per la tabella */
        .table-responsive {
            overflow-x: auto;
            margin-bottom: 30px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .table th {
            background-color: #f5f5f5;
            font-weight: bold;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
<div class="container-fluid container-fluid-spacious">
    <div class="dashhead mt-4">
  <div class="dashhead-titles">
    <h6 class="dashhead-subtitle">Dashboards</h6>
    <h2 class="dashhead-title">Overview</h2>
  </div>
  <div class="btn-toolbar dashhead-toolbar">
    <div class="btn-toolbar-item input-with-icon">
      <input type="text" value="01/01/15" class="form-control" data-provide="datepicker">
      <span class="icon icon-calendar"></span>
    </div>
    <div class="btn-toolbar-item input-with-icon">
      <input type="text" value="01/08/15" class="form-control" data-provide="datepicker">
      <span class="icon icon-calendar"></span>
    </div>
  </div>
</div>

<div class="hr-divider mt-3 mb-5">
  <h3 class="hr-divider-content hr-divider-heading">Quick stats</h3>
</div>



<div class="hr-divider my-4">
  <ul class="nav nav-pills hr-divider-content hr-divider-nav" role="tablist">
    <li class="nav-item" role="presentation">
      <a href="#sales" class="nav-link active" role="tab" data-toggle="tab" aria-controls="sales">Sales</a>
    </li>
    <li class="nav-item" role="presentation">
      <a href="#inventory" class="nav-link" role="tab" data-toggle="tab" aria-controls="inventory">Inventory</a>
    </li>
    <li class="nav-item" role="presentation">
      <a href="#profit" class="nav-link" role="tab" data-toggle="tab" aria-controls="profit">Profit</a>
    </li>
  </ul>
</div>
<div class="tab-content">
  <div role="tabpanel" class="tab-pane active" id="sales">
      <div class="ex-line-graphs">
        <canvas id="copertiChart"></canvas>
      </div>
  </div>

    <div role="tabpanel" class="tab-pane" id="inventory">
      <div class="ex-line-graphs">
      <canvas id="piattiCameriereChart"></canvas>
      </div>
    </div>

    <div role="tabpanel" class="tab-pane" id="profit">
      <div class="ex-line-graphs">
      <canvas id="piattoPiuVendutoChart"></canvas>
      </div>
    </div>

  
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/chart.js"></script>
    <script src="js/tablesorter.min.js"></script>
    <script src="js/toolkit.js"></script>
    <script src="js/application.js"></script>
    <script>
        $(function(){
            // Dati di esempio (da sostituire con i tuoi dati reali)
            var copertiData = {
                labels: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno'],
                datasets: [{
                    label: 'Numero di coperti',
                    data: [50, 60, 70, 80, 90, 100],
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            };

            var piattiCameriereData = {
                labels: ['Marco', 'Luca', 'Giovanni', 'Maria', 'Francesca'],
                datasets: [{
                    label: 'Numero di piatti venduti',
                    data: [20, 30, 25, 35, 40],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            };

            var piattoPiuVendutoData = {
                labels: ['Pasta', 'Pizza', 'Insalata', 'Carne', 'Pesce'],
                datasets: [{
                    label: 'Numero di vendite',
                    data: [100, 90, 80, 70, 60],
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            };

            // Creazione dei grafici
            var copertiChart = new Chart(document.getElementById('copertiChart'), {
                type: 'line',
                data: copertiData,
                options: {}
            });

            var piattiCameriereChart = new Chart(document.getElementById('piattiCameriereChart'), {
                type: 'bar',
                data: piattiCameriereData,
                options: {}
            });

            var piattoPiuVendutoChart = new Chart(document.getElementById('piattoPiuVendutoChart'), {
                type: 'bar',
                data: piattoPiuVendutoData,
                options: {}
            });
        });
    </script>
</body>
</html>




<!---->

