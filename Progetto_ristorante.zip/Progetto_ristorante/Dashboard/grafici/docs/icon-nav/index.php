<?php
session_start();
require '../../../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../../../login.php');
    die();
}
require '../../../../connection.php';
?>  
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Icon nav &middot; 
      
    </title>

    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic" rel="stylesheet">
    
      <link href="../assets/css/toolkit-inverse.css" rel="stylesheet">
    
    
    <link href="../assets/css/application.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        width: 100%;
      }
      #centro {
        justify-content: center;
        align-items: center;
        
      }
    </style>
  </head>
<body>
  <?php
  if ($_SERVER["REQUEST_METHOD"] === "GET" && !empty($_GET['date1']) && !empty($_GET['date2'])) {
    $date1 = mysqli_real_escape_string($conn, $_GET["date1"]);
    $date2 = mysqli_real_escape_string($conn, $_GET["date2"]);
  } else {
    $date1 = date('Y-m-d');
    $date2 = date('Y-m-d');
  }



  $sql4 = "SELECT date";
  /*----------------------------------------------------------*/
  //guadagni all'ora
  $sql4 = "SELECT 
  FLOOR(TIME_TO_SEC(TIME(c.date)) / 3600) AS ora_arrotondata,
  SUM(c.quantita * m.prezzo) AS totale_prodotto
FROM 
  menu m
INNER JOIN 
  conferma c ON m.id = c.codPiatto
WHERE DATE(C.date) = '$date1'
GROUP BY 
  ora_arrotondata;";
  $ora = [];
  $i = 0;
  $result4 = $conn->query($sql4);
  while ($row5 = mysqli_fetch_assoc($result4)) {
    $resultArray[$row5['ora_arrotondata']] = $row5['totale_prodotto'];
}
  /*if ($result4->num_rows > 0) {
    // Output dei dati di ogni riga
    while($row4 = $result4->fetch_assoc()) {
      $data = explode(" ", $row4['date']);
      $prova = $data[1];
      $prova = explode(":", $prova);
      $bibo = explode(":", $prova[0]);
      $ora[$i]['Time'] = $bibo[0]; 
      $ora[$i]['Prezzo'] = $row4['prezzo'];
      $ora[$i]['Quantita'] = $row4['quantita'];
      $i++;
    }
    $second = [];
    $z = 0;
    for ($i = 0; $i < count($ora); $i++) {
      // Valore da cercare nella colonna "Time"
      $value_to_find = $ora[$i]['Time'];
      $value_to_add = $ora[$i]['Prezzo'];
      $value_to_molt = $ora[$i]['Quantita'];
  
      // Flag per indicare se il valore è stato trovato
      $found = false;
  
      // Itera attraverso ogni elemento dell'array
      foreach ($second as $key => $element) {
          // Cerca il valore nella colonna "Time" dell'elemento corrente
          if ($value_to_find == $element["Time"]) {
              $found = true;
              // Modifica direttamente il prezzo nell'array $second
              $second[$key]["Prezzo"] += ($value_to_add * $value_to_molt);
              break;
          }
      }
  
      // Stampa il risultato
      if (!$found) {
          // Se il valore non è stato trovato, aggiungilo a $second
          $second[$z]['Time'] = $value_to_find;
          $second[$z]['Prezzo'] = ($value_to_add * $value_to_molt);
          $z++;
      }
  }

  }*/

  /*------------------------------------------------------------*/
  //coperti giornalieri   OK!
  $sql = "SELECT tavolo, num, coperti, date FROM conferma WHERE DATE(date) = CURRENT_DATE GROUP BY tavolo, num;";
  $count = 0;
  $somma = 0;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    // Output dei dati di ogni riga
    while($row = $result->fetch_assoc()) {
        $somma += $row['coperti'];
      
    }
  }
  /*------------------------------------------------------------*/
  //media coperti       OK!
  $sql3 = "SELECT AVG(media_coperti) AS media_totale
  FROM (
      SELECT tavolo, num, AVG(coperti) AS media_coperti
      FROM (
          SELECT DISTINCT tavolo, num, coperti, date
          FROM conferma
          WHERE DATE(date) >= '$date1' AND DATE(date) <= '$date2'
      ) AS subquery
      GROUP BY tavolo, num
  ) AS media;
  ";
  $mediaCosto = 0;
 $media = 0;
  $result3 = $conn->query($sql3);
  $i = 0;
  $row9 = $result3->fetch_assoc();
  if ($row9) {
      $media = $row9['media_totale'];
  } else {
      $media = 0;
  }
  /*----------------------------------------------------------*/
  //quanto costa un cameriere e quanto mi fa guadagnare e fatturato     OK!
  $sql2 = "SELECT c.codCameriere, 
  SUM(c.quantita) as totale_quantita, 
  SUM(c.quantita * m.prezzo) as totale_costo,
  a.username, a.costo
  FROM conferma c
  INNER JOIN account a ON c.codCameriere = a.id
  INNER JOIN menu m ON c.codPiatto = m.id
  WHERE DATE(c.date) >= '$date1' AND DATE(c.date) <= '$date2'
  GROUP BY c.codCameriere, a.username, a.costo";
  
  $dipendenti = [];
  $fatturato = 0;
  $i = 0;
  $result2 = $conn->query($sql2);

  if ($result2->num_rows > 0) {
      // Output dei dati di ogni riga
      while($row2 = $result2->fetch_assoc()) {
        if ($row2["username"] != 'Capo') {
          $dipendenti[$i]['Nome']  = $row2["username"];
          $dipendenti[$i]['Costo']  = $row2["totale_costo"];
          $fatturato += $row2["totale_costo"];
          $dipendenti[$i]['Dipendente']  = $row2["costo"];
          $dipendenti[$i]['Quantita']  = $row2["totale_quantita"];
          $i++;
        }
          
      }
  }
  /*--------------------------------------------------------------------*/

    //conteggio piatti e ordinazione dei piatti   OK!
    $sql1 = "SELECT date, menu.nome, conferma.codPiatto, COUNT(conferma.codPiatto) as conteggio, SUM(conferma.quantita) as somma_quantita
    FROM conferma
    JOIN menu ON conferma.codPiatto = menu.id
    WHERE DATE(date) >= '$date1' AND DATE(date) <= '$date2'
    GROUP BY conferma.codPiatto 
    ORDER BY somma_quantita DESC";
    $result1 = $conn->query($sql1);

    $array = [];

    if ($result1->num_rows > 0) {
    // Stampa i risultati
    $i = 0;
    while($row1= $result1->fetch_assoc()) {
        $array[$i]['Nome'] = $row1["nome"];
        $array[$i]['Quantita'] = $row1["somma_quantita"];
        $i++;
      }
    } else {
    //echo "Nessun risultato trovato";
    }
    /*--------------------------------------------------------------------*/
    //media spesa cliente
    //spesa
    
    //coperti
    $sql7= "SELECT COALESCE(SUM(media_coperti), 0) AS somma_totale
        FROM (
            SELECT tavolo, num, SUM(coperti) AS media_coperti
            FROM (
                SELECT DISTINCT tavolo, num, coperti
                FROM conferma
                WHERE DATE(date) = '$date1'
            ) AS subquery
           
            GROUP BY tavolo, num
        ) AS somma";

      $result7 = mysqli_query($conn, $sql7);

      if (mysqli_num_rows($result7) > 0) {
          // Output dei dati di ogni riga
          $row7 = mysqli_fetch_assoc($result7);
          if ($fatturato < $row7['somma_totale'] || $row7['somma_totale'] == 0) {
            $mediaCosto = 0;
          } else {
            $mediaCosto = $fatturato / $row7['somma_totale'];
          }
          
      } else {
          $mediaCosto = 0;
      }


      

  ?>



<div class="with-iconav">

  <nav class="iconav">
    
    <div class="iconav-slider">
      <ul class="nav nav-pills iconav-nav flex-md-column">
        <li class="nav-item">
          <a class="nav-link" href="../../../grafici.php" title="Indietro" data-toggle="tooltip" data-placement="right" data-container="body">
            <span class="icon icon-home"></span>
            <small class="iconav-nav-label hidden-md-up">Grafici</small>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link active" href="#" title="" data-toggle="tooltip" data-placement="right" data-container="body">
            <span class="icon icon-area-graph"></span>
            <small class="iconav-nav-label hidden-md-up">Icon nav</small>
          </a>
        </li>
      
      </ul>
    </div>
  </nav>

  <div class="container">
    <div class="dashhead">
      <div class="dashhead-titles">
        <h6 class="dashhead-subtitle">Dashboards</h6>
        <h3 class="dashhead-title">Grafici</h3>
      </div>

      <div class="dashhead-toolbar">
      <form id="dateForm" action="index.php" method="GET">
      <div class="form-inline">
      <button onclick="resetDateField()" type="submit" class="btn btn-secondary">Reset</button>
      
       
          <input type="date" value="<?php echo $date1;?>" class="form-control"  name="date1" id="date1">
          
    
          <input type="date" value="<?php echo $date2;?>" class="form-control"  name="date2" id="date2">
         
          <button type="submit" value="Submit" class="btn btn-primary">Invio</button>
        
        </div>
      </form> 
       
        <!--<span class="dashhead-toolbar-divider hidden-sm-down"></span>
        <div class="btn-group dashhead-toolbar-item btn-group-thirds">
          <button type="button" class="btn btn-outline-primary">Day</button>
          <button type="button" class="btn btn-outline-primary active">Week</button>
          <button type="button" class="btn btn-outline-primary">Month</button>
        </div>-->
      </div>
    </div>

    <ul class="nav nav-bordered mt-4 mt-md-2 mb-0 clearfix" role="tablist">
      <li class="nav-item" role="presentation">
        <a href="#traffic" class="nav-link active" role="tab" data-toggle="tab" aria-controls="traffic">Rendimento</a>
      </li>
      <li class="nav-item" role="presentation">
        <a href="#sales" class="nav-link" role="tab" data-toggle="tab" aria-controls="sales">Vendite</a>
      </li>
      <!--<li class="nav-item" role="presentation">
        <a href="#support" class="nav-link" role="tab" data-toggle="tab" aria-controls="support">Support</a>
      </li>-->
    </ul>

    <hr class="mt-0 mb-5">

    <div class="tab-content">
      <div role="tabpanel" class="tab-pane active" id="traffic">
        <div class="row text-center m-t-md">
        <?php for ($i = 0; $i < count($dipendenti); $i++) {
          ?>
          <div class="col-md-4 mb-5">
              <div class="w-3 mx-auto">
                <canvas
                  class="ex-graph"
                  width="200" height="200"
                  data-chart="doughnut"
                  data-dataset="[<?php echo $dipendenti[$i]['Dipendente'];?>, <?php echo $dipendenti[$i]['Costo'];?>]"
                  data-dataset-options="{ borderColor: '#252830', backgroundColor: ['#1ca8dd', '#1bc98e'] }"
                  data-labels="['Stipendio', 'Venduto']"
                  >
                </canvas>
              </div>
              <strong class="text-muted">Spesa/Guadagno</strong>
              <h4><?php echo $dipendenti[$i]['Nome'];?></h4>
            </div>
            <?php }?>
        
          </div>
      </div>

      <div role="tabpanel" class="tab-pane" id="sales">
        <div class="ex-line-graphs mb-5">
          <canvas
            class="ex-line-graph"
            width="600" height="400"
            data-chart="line"
            data-dataset="[[ <?php foreach ($resultArray as $ora => $totale) {
                              if ($totale === end($resultArray)) {
                                echo $totale;
                              } else {
                                echo $totale . ",";
                              }
                          }?>]]"
            data-labels="[<?php foreach ($resultArray as $ora => $totale) {
                              if ($totale === end($resultArray)) {
                                echo "'" . $ora . "'";
                              } else {
                                  echo "'" . $ora . "',";
                              }
                              
                          }?>]"
            data-dark="true">
        
          </canvas>
        </div>
      </div>


      <!--<div role="tabpanel" class="tab-pane" id="support">
        <div class="ex-line-graphs mb-5">
          <canvas
            class="ex-line-graph"
            width="600" height="400"
            data-chart="bar"
            data-dark="true"
            data-labels="['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre']"
            data-dataset="[[65, 59, 80, 81, 56, 55, 40], [28, 48, 40, 19, 86, 27, 90]]"
            data-dataset-options="[{label: 'First dataset'}, {label: 'Second dataset'}]">
          </canvas>
        </div>
      </div>-->
    </div>

    <div class="hr-divider my-4">
      <h3 class="hr-divider-content hr-divider-heading">Quick stats</h3>
    </div>

    <div class="row statcards mt-3 mb-3 text-xs-center text-md-left">
      <div class="col-6 col-md-3 statcard mb-4">
        <h3 class="statcard-number text-success">
          <?php echo $somma;?>
        </h3>
        <span class="statcard-desc">Coperti giornalieri</span>
      </div>
      <div class="col-6 col-md-3 statcard mb-4">
        <h3 class="statcard-number text-success">
        <?php echo round($media, 2);?>
        </h3>
        <span class="statcard-desc">Media coperti</span>
      </div>
      <div class="col-6 col-md-3 statcard mb-4">
        <h3 class="statcard-number text-success">
        <?php echo $fatturato;?>
        </h3>
        <span class="statcard-desc">Incasso totale</span>
      </div>
      <div class="col-6 col-md-3 statcard mb-4">
        <h3 class="statcard-number text-success">
          <?php echo  round($mediaCosto, 2);?>
        </h3>
        <span class="statcard-desc">Spesa media cliente</span>
      </div>
    </div>

    <hr class="my-4">

    <div class="row justify-content-center">
      <div class="col-lg-4 mb-5">
        <div class="list-group mb-3">
          <h6 class="list-group-header">
            Piatti più venduti
          </h6>
          <?php
          for ($i = 0; $i < count($array); $i++) {
          ?>
          <a class="list-group-item list-group-item-action justify-content-between" href="#">
            <span><?php echo $array[$i]['Nome']?></span>
            <span class="text-muted"><?php echo $array[$i]['Quantita']?></span>
          </a>
          <?php
          }?>
        </div>
      </div>
      <!--<div class="col-lg-4 mb-5">
        <div class="list-group mb-3">
          <h6 class="list-group-header">
            Most visited pages
          </h6>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/ (Logged out)</span>
              <span class="text-muted">3,929,481</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/ (Logged in)</span>
              <span class="text-muted">1,143,393</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/tour</span>
              <span class="text-muted">938,287</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/features/something</span>
              <span class="text-muted">749,393</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/features/another-thing</span>
              <span class="text-muted">695,912</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/users/username</span>
              <span class="text-muted">501,938</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/page-title</span>
              <span class="text-muted">392,842</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/some/page-slug</span>
              <span class="text-muted">298,183</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/another/directory/and/page-title</span>
              <span class="text-muted">193,129</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>/one-more/page/directory/file-name</span>
              <span class="text-muted">93,382</span>
            </a>
          
        </div>
        <a href="#" class="btn btn-outline-primary px-3">View all pages</a>
      </div>-->
      <!--<div class="col-lg-4 mb-5">
        <div class="list-group mb-3">
          <h6 class="list-group-header">
            Devices and resolutions
          </h6>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Desktop (1920x1080)</span>
              <span class="text-muted">3,929,481</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Desktop (1366x768)</span>
              <span class="text-muted">1,143,393</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Desktop (1440x900)</span>
              <span class="text-muted">938,287</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Desktop (1280x800)</span>
              <span class="text-muted">749,393</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Tablet (1024x768)</span>
              <span class="text-muted">695,912</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Tablet (768x1024)</span>
              <span class="text-muted">501,938</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Phone (320x480)</span>
              <span class="text-muted">392,842</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Phone (720x450)</span>
              <span class="text-muted">298,183</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Desktop (2560x1080)</span>
              <span class="text-muted">193,129</span>
            </a>
          
            <a class="list-group-item list-group-item-action justify-content-between" href="#">
              <span>Desktop (2560x1600)</span>
              <span class="text-muted">93,382</span>
            </a>
          
        </div>
        <a href="#" class="btn btn-outline-primary px-3">View all pages</a>
      </div>-->
    </div>


  </div>
</div>


    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/tether.min.js"></script>
    <script src="../assets/js/chart.js"></script>
    <script src="../assets/js/tablesorter.min.js"></script>
    <script src="../assets/js/toolkit.js"></script>
    <script src="../assets/js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){while(window.BS&&window.BS.loader&&window.BS.loader.length){(window.BS.loader.pop())()}})

      function resetDateField() {
    document.getElementById("date1").value = "<?php echo date('Y-m-d'); ?>";
    document.getElementById("date2").value = "<?php echo date('Y-m-d'); ?>";
  }
    </script>
  </body>
</html>

