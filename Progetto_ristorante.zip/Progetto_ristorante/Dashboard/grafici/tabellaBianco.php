<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Fluid &middot; 
      
    </title>

    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic" rel="stylesheet">
    
      <link href="css/toolkit-light.css" rel="stylesheet">
    
    
    <link href="css/application.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
    </style>
  </head>


<body class="with-top-navbar">



  <div class="container-fluid container-fluid-spacious">
    <div class="dashhead mt-4">
  <div class="dashhead-titles">
    <h6 class="dashhead-subtitle">Dashboards</h6>
    <h2 class="dashhead-title">Overview</h2>
  </div>
  <div class="btn-toolbar dashhead-toolbar">
    <div class="btn-toolbar-item input-with-icon">
      <input type="text" value="01/01/15" class="form-control" data-provide="datepicker">
      <span class="icon icon-calendar"></span>
    </div>
    <div class="btn-toolbar-item input-with-icon">
      <input type="text" value="01/08/15" class="form-control" data-provide="datepicker">
      <span class="icon icon-calendar"></span>
    </div>
  </div>
</div>

<div class="hr-divider mt-3 mb-5">
  <h3 class="hr-divider-content hr-divider-heading">Quick stats</h3>
</div>

<div class="hr-divider my-4">
  <ul class="nav nav-pills hr-divider-content hr-divider-nav" role="tablist">
    <li class="nav-item" role="presentation">
      <a href="#sales" class="nav-link active" role="tab" data-toggle="tab" aria-controls="sales">Sales</a>
    </li>
    <li class="nav-item" role="presentation">
      <a href="#inventory" class="nav-link" role="tab" data-toggle="tab" aria-controls="inventory">Inventory</a>
    </li>
    <li class="nav-item" role="presentation">
      <a href="#profit" class="nav-link" role="tab" data-toggle="tab" aria-controls="profit">Profit</a>
    </li>
  </ul>
</div>

<div class="tab-content">
  <div role="tabpanel" class="tab-pane active" id="sales">
    <div class="ex-line-graphs">
       <canvas
        class="ex-line-graph"
        width="600" height="350"
        data-chart="line"
        data-dataset="[[2500, 3300, 2512, 2775, 2498, 3512, 2925, 4275, 3507, 3825, 3445, 3985]]"
        data-labels="['','Aug 29','','','Sept 5','','','Sept 12','','','Sept 19','']">
      </canvas>
    </div>
  </div>

  <div role="tabpanel" class="tab-pane" id="inventory">
    <div class="ex-line-graphs">
      <canvas
        class="ex-line-graph"
        width="600" height="400"
        data-chart="bar"
        data-labels="['August','September','October','November','December','January','February']"
        data-dataset="[[65, 59, 80, 81, 56, 55, 40], [28, 48, 40, 19, 86, 27, 90]]"
        data-dataset-options="[{label: 'First dataset'}, {label: 'Second dataset'}]">
      </canvas>
    </div>
  </div>

  <div role="tabpanel" class="tab-pane" id="profit">
    <div class="row ex-graphs text-center">
      <div class="col-sm-4 mb-4 mb-sm-0">
        <div class="w-3 mx-auto">
          <canvas
            class="ex-graph"
            width="200" height="200"
            data-chart="doughnut"
            data-dataset="[230, 130]"
            data-dataset-options="{ backgroundColor: ['#1ca8dd', '#1bc98e'] }"
            data-labels="['Returning', 'New']">
          </canvas>
        </div>
        <strong class="text-muted">Traffic</strong>
        <h3>New vs Returning</h3>
      </div>
      <div class="col-sm-4 mb-4 mb-sm-0">
        <div class="w-3 mx-auto">
          <canvas
            class="ex-graph"
            width="200" height="200"
            data-chart="doughnut"
            data-dataset="[330, 30]"
            data-dataset-options="{ backgroundColor: ['#1ca8dd', '#1bc98e'] }"
            data-labels="['Returning', 'New']">
          </canvas>
        </div>
        <strong class="text-muted">Revenue</strong>
        <h3>New vs Recurring</h3>
      </div>
      <div class="col-sm-4 mb-4 mb-sm-0">
        <div class="w-3 mx-auto">
          <canvas
            class="ex-graph"
            width="200" height="200"
            data-chart="doughnut"
            data-dataset="[100, 260]"
            data-dataset-options="{ backgroundColor: ['#1ca8dd', '#1bc98e'] }"
            data-labels="['Referrals', 'Direct']"
            >
          </canvas>
        </div>
        <strong class="text-muted">Traffic</strong>
        <h3>Direct vs Referrals</h3>
      </div>
    </div>
  </div>
</div>

<div class="hr-divider mt-5 mb-4">
  <h3 class="hr-divider-content hr-divider-heading">Tabella</h3>
</div>
<div class="table-responsive">
  <table class="table" data-sort="table">
    <thead>
      <tr>
        
        <th>Order</th>
        <th>Customer name</th>
        <th>Description</th>
        <th>Date</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>
      <tr>
         
        <td><a href="#">#10001</a></td>
        <td>First Last</td>
        <td>Admin theme, marketing theme</td>
        <td>01/01/2015</td>
        <td>$200.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10002</a></td>
        <td>Firstname Last</td>
        <td>Admin theme</td>
        <td>01/01/2015</td>
        <td>$100.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10003</a></td>
        <td>Name Another</td>
        <td>Personal blog theme</td>
        <td>01/01/2015</td>
        <td>$100.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10004</a></td>
        <td>One More</td>
        <td>Marketing theme, personal blog theme, admin theme</td>
        <td>01/01/2015</td>
        <td>$300.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10005</a></td>
        <td>Name Right Here</td>
        <td>Personal blog theme, admin theme</td>
        <td>01/02/2015</td>
        <td>$200.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10006</a></td>
        <td>First Last</td>
        <td>Admin theme, marketing theme</td>
        <td>01/01/2015</td>
        <td>$200.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10007</a></td>
        <td>Firstname Last</td>
        <td>Admin theme</td>
        <td>01/01/2015</td>
        <td>$100.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10008</a></td>
        <td>Name Another</td>
        <td>Personal blog theme</td>
        <td>01/01/2015</td>
        <td>$100.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10009</a></td>
        <td>One More</td>
        <td>Marketing theme, personal blog theme, admin theme</td>
        <td>01/01/2015</td>
        <td>$300.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10010</a></td>
        <td>Name Right Here</td>
        <td>Personal blog theme, admin theme</td>
        <td>01/02/2015</td>
        <td>$200.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10011</a></td>
        <td>First Last</td>
        <td>Admin theme, marketing theme</td>
        <td>01/01/2015</td>
        <td>$200.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10012</a></td>
        <td>Firstname Last</td>
        <td>Admin theme</td>
        <td>01/01/2015</td>
        <td>$100.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10013</a></td>
        <td>Name Another</td>
        <td>Personal blog theme</td>
        <td>01/01/2015</td>
        <td>$100.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10014</a></td>
        <td>One More</td>
        <td>Marketing theme, personal blog theme, admin theme</td>
        <td>01/01/2015</td>
        <td>$300.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10015</a></td>
        <td>Name Right Here</td>
        <td>Personal blog theme, admin theme</td>
        <td>01/02/2015</td>
        <td>$200.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10016</a></td>
        <td>First Last</td>
        <td>Admin theme, marketing theme</td>
        <td>01/01/2015</td>
        <td>$200.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10017</a></td>
        <td>Firstname Last</td>
        <td>Admin theme</td>
        <td>01/01/2015</td>
        <td>$100.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10018</a></td>
        <td>Name Another</td>
        <td>Personal blog theme</td>
        <td>01/01/2015</td>
        <td>$100.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10019</a></td>
        <td>One More</td>
        <td>Marketing theme, personal blog theme, admin theme</td>
        <td>01/01/2015</td>
        <td>$300.00</td>
      </tr>
      <tr>
         
        <td><a href="#">#10020</a></td>
        <td>Name Right Here</td>
        <td>Personal blog theme, admin theme</td>
        <td>01/02/2015</td>
        <td>$200.00</td>
    </tbody>
  </table>
</div>

</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/chart.js"></script>
    <script src="js/tablesorter.min.js"></script>
    <script src="js/toolkit.js"></script>
    <script src="js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){while(window.BS&&window.BS.loader&&window.BS.loader.length){(window.BS.loader.pop())()}})
    </script>
  </body>
</html>

