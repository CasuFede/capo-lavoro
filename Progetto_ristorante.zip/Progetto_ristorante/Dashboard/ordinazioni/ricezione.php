<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || (getUserEmail() != "Capo" && getUserEmail() != "Cameriere1" && getUserEmail() != "Cameriere2")) {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ottieni il valore della quantità dall'input POST
    $tmp = [];
    if (empty($_POST['arrayP'])) {
        echo "Errore nel inserimento delle ordinazioni";
    } else {
        $tmp = $_POST['arrayP'];
        echo "<pre>";
        print_r($tmp);
        echo "</pre>";
        $nom = ['Antipasti', 'Primi', 'Secondi', 'Dolci', 'Bibite', 'Vini'];
        echo count($tmp);
        for ($i = 0; $i < 6; $i++) {
            echo "i: " . $i;
            for($j = 0; $j < count($tmp[$nom[$i]]); $j++){
                echo "<pre>";
                print_r($tmp[$nom[$i]][$j]);
                echo "</pre>";
                
                if ($tmp[$nom[$i]][$j]["Quantita"] != 0) {
                    $tavolo = mysqli_real_escape_string($conn, $tmp["Tavolo"]);
                    $coperti = mysqli_real_escape_string($conn, $tmp["Coperti"]);
                    $nome = mysqli_real_escape_string($conn, $tmp[$nom[$i]][$j]["Nome"]);
                    $quantita = mysqli_real_escape_string($conn, $tmp[$nom[$i]][$j]["Quantita"]);
                    
                    // Aggiunte
                    $aggiunte = "";
                    if (!empty($tmp[$nom[$i]][$j]["Aggiunte"])) {
                        $aggiunte = mysqli_real_escape_string($conn, implode("-", $tmp[$nom[$i]][$j]["Aggiunte"]));
                    }

                    // Descrizione
                    $descrizione = "";
                    if (!empty($tmp[$nom[$i]][$j]["Descrizione"])) {
                        $descrizione = mysqli_real_escape_string($conn, $tmp[$nom[$i]][$j]["Descrizione"]);
                    }

                    // Ottieni l'ID del piatto
                    $sql = "SELECT id FROM menu WHERE nome = '$nome'";
                    $result = mysqli_query($conn, $sql);
                    if ($result && mysqli_num_rows($result) > 0) {
                        $row = mysqli_fetch_assoc($result);

                        $sql2 = "SELECT tavolo, num, stato, id, pagato FROM conferma WHERE tavolo = $tavolo";
                        $result2 = mysqli_query($conn, $sql2);
                        // Verifica se ci sono risultati
                        if (mysqli_num_rows($result2) > 0) {
                            // Output dei dati
                            $max = 0;
                            $check = -1;
                            while($row2 = mysqli_fetch_assoc($result2)) {
                                if ($row2["tavolo"] == $tavolo) {
                                    if ($row2["stato"] == "Pronto" && $row2["pagato"] == "Si") {
                                        if ($max < $row2["num"]) {
                                            $max = $row2["num"];
                                        }
                                        if ($max == 0) {
                                            $check = 0;
                                        } elseif ($max > 0) {
                                            $check = 1;
                                        }
                                        
                                    }
                                } else {
                                    $check = -1;
                                }
                            }
                            if ($check == -1) {
                                $max = 0;
                            } elseif ( $check == 0) {
                                $max = 1;
                            } elseif($check == 1) {
                                $max++;
                            }
                        } else {
                            $max = 0;
                        }
                        $id = $row['id'];
                        // Inserisci i dati nella tabella "conferma"
                        $now = date("Y-m-d H:i:s");
                        $cameriere = getUserId();
                        $sql_insert = "INSERT INTO conferma (`tavolo`, `date`, `codPiatto`, `aggiunte`, `quantita`, `descrizione`, `stato`, pagato, num, codCameriere, coperti) 
                                    VALUES ('$tavolo', '$now', '$id', '$aggiunte', '$quantita', '$descrizione', 'Attesa', 'No', '$max', '$cameriere', '$coperti')";
                        if (!$conn->query($sql_insert)) {
                            echo "Errore durante l'inserimento dei dati: " . $conn->error;
                        }
                    } else {
                        echo "Errore durante il recupero dell'ID del piatto.";
                    }
                }
            }
        }

        header('Location:invio.php');
        die();
    }
} else {
    // Altra logica nel caso non sia una richiesta POST
}
?>

