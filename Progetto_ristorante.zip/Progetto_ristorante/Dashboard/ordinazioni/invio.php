<?php
require 'developers.php';
// Creazione di un ID di sessione personalizzato

?>
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
<!--Refresh page-->
    <!--<meta http-equiv="refresh" content="3; URL=#">-->
<!---->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Invio Dati</title>
  <!--Bootstrap-->
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/headers/">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
            body {
            font-family: Arial, sans-serif !important;
            margin: 0;
            padding: 0;
        }

        /*menu a tendina*/
        header {
            position: fixed; /* Fissa la navbar */
            top: 0; /* La colloca all'inizio della pagina */
            width: 100%; /* Occupa l'intera larghezza della finestra del browser */
            background-color: #333; /* Colore di sfondo della navbar */
            padding: 5px 0; /* Spaziatura interna sopra e sotto */
            background-color: #333;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4); /* Aggiunta di ombra al fondo */
            
        }   
        .container {
            display: flex;
            margin: 0; 
            padding: 0;
        }
        main {
            padding-top: 60px;
            margin-left: 10px;

            transition: margin-left 0.5s;
        }
        .open-btn {
            font-size: 20px;
            cursor: pointer;
            color: white;
            background-color: #333;
            border: none;
            
        }

        .sidebar {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #222;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
            
        }

        .sidebar a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 20px;
            color: #ddd;
            display: block;
            transition: 0.3s;
            
        }

        .sidebar a:hover {
            background-color: #555;
            color: white;
        }

        .sidebar .closebtn {
            position: absolute;
            top: 0;
            right: 20px;
            font-size: 30px;
            margin-left: 50px;
            color: white;
            
        }
        /*portate*/
        .container1 {
            display: flex;
            align-items: center;
            justify-content: left;
            
        }
        #food {
            font-size: 24px;
            margin: 0;
            text-align: center;
            font-weight: bold;
            margin-right: 20px;
            margin-left: -14px;
        }
        #btn {
            font-size: 18px;
            color: black;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        #btn:hover{
        background-color: white; 
        }
        #quantity {
            font-size: 18px;
            width: 50px;
            text-align: center;
        }

        /*dimensione portate*/ 
        #item {
            background-color: #f4f4f4;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px; /*modifica l'altezza tra 2 portate*/
        }

        /*menu a tendina opzioni*/
        
        .options {
            display: none;
        }
        .option-label {
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            text-decoration: none;
        }
        .dropdown {
            margin-top: 10px;
            
        }
        .dropdown label {
            display: block;
        }
        .dropdown input[type="checkbox"] {
            margin-right: 5px;
        }

        .category {
            margin-bottom: 20px;
        }

        .category h2 {
            margin-top: 0;
        }
        /*textarea*/
        /* Stile di base per la textarea */
    textarea {
        margin-left: 20px;
        width: 300px;
        height: 30px;
        transition: width 0.5s, height 0.5s, z-index 0.5s, top 0.5s, left 0.5s;
        /*position: relative; /* Posizione relativa per consentire il posizionamento assoluto */
        
    }

    /* Stile per la textarea ingrandita */
    textarea.expanded {
        width: 70%;
        height: 50%;
        /*z-index: 9999; /* Assicura che la textarea ingrandita sia sopra a tutti gli altri elementi */
        top: 25%; /* Posiziona la textarea al centro verticale */
        left: 15%; /* Posiziona la textarea al centro orizzontale */
        position: fixed;
    }
    
    /*input tavolo e coperti*/
        .contain {
            display: inline-block;
        }
        
        .box {
            margin-right: 10px;
        }
        #tavolo{
            width: 200px;
        }
        #coperti{
            width: 120px;
        }

        /*botton item*/
        .bottom-items {
            position: absolute;
            bottom: 0;
            display: flex;
            width: 100% !important;
            }
        .bottom-item {
        color: white !important;
        width: 50% !important;
            }
        .bottom-item2 {
            color: white !important;
            width: 50% !important;
        }
        
    /* Media query per dispositivi con larghezza massima di 480px (tipicamente dispositivi mobile) */
    @media only screen and (max-width: 600px) {
        textarea {
        width: 100px;
        height: 30px;
        }

        textarea.expanded {
        width: 70%;
        left: 15%;
        }
    }


        /*responsive*/
        @media screen and (max-height: 450px) {
            .sidebar {padding-top: 15px;}
            .sidebar a {font-size: 18px;}
        }
        @media screen and (max-width: 600px) {
            .sidebar a {
                font-size: 25px; /* Cambia il valore a tuo piacimento */
            }
            header {
                display: flex;
                height: 50px;
            }
        
            .option-label{
                font-size: 14px;
            }
            #food {
                font-size: 14px;
                margin-right: 0;
            }
            #btn {
                font-size: 14px;
                padding: 8px 16px;
            }
            #quantity {
                font-size: 16px;
                padding: 8px;
                width: 40px;
            }
        }

    
    </style>
  </head>
  <body>
   
    <header>
        <div class="container">
            <button class="open-btn" onclick="openNav()">☰</button>
            <div id="mySidebar" class="sidebar">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
                <a href="#antipasti">Antipasti</a>
                <a href="#primi">Primi</a>
                <a href="#secondi">Secondi</a>
                <a href="#dolci">Dolci</a>
                <a href="#bibite">Bibite</a>
                <a href="#vini">Vini</a>
                <div class="bottom-items">
                    <a class="bottom-item">
                        <form action="../../logout.php" method="POST">
                            <input type="hidden" name="logout" value="1">
                            <button class="nav-link d-flex align-items-center gap-2" style="--c: #373B44;--b: 5px;--s:12px">Logout</button>
                        </form>
                    </a>
                
                    <a href="conferma.php" class="bottom-item2">Conferma</a>
                </div>
            </div>
        </div>
    </header>
    <main>
        <?php
        $i = 0;
        $a = 0;
        $b = 0;
        $c = 0;
        $d = 0;
        $e = 0;
        if(is_array($fetchData)){      
        foreach($fetchData as $data){
            if ($data['sezione'] == 'Antipasti') {
            $array['Antipasti'][$i] = $data;
            $i++;
            }
            if ($data['sezione'] == 'Primi') {
            $array['Primi'][$a] = $data;
            $a++;
            }
            if ($data['sezione'] == 'Secondi') {
            $array['Secondi'][$b] = $data;
            $b++;
            }
            if ($data['sezione'] == 'Dolci') {
            $array['Dolci'][$c] = $data;
            $c++;
            }
            if ($data['sezione'] == 'Vini') {
            $array['Vini'][$d] = $data;
            $d++;
            }
            if ($data['sezione'] == 'Bibite') {
            $array['Bibite'][$e] = $data;
            $e++;
            }
            
        }
    }
        /*echo "<pre>";
        print_r($array);
        echo "</pre>";*/
        $j = 0;
        ?>
      <form action="ricezione.php" method="post">
        <div class="contain">
            <input type="text" class="box" id="tavolo" name="arrayP[Tavolo]" placeholder="Inserire il codice del tavolo" required>
            <input type="number" class="box" id="coperti" name="arrayP[Coperti]" placeholder="num coperti" required>
        </div>
        <!--ANTIPASTI-->
        <div class="category">
            <?php
            if (!empty($array['Antipasti'])) {
            ?> 
            <h2 id="antipasti">Antipasti</h2>
            <?php
                for ($i = 0; $i < count($array['Antipasti']); $i++) {
                $nomePiatto = $array['Antipasti'][$i]['nome'];
            ?>
            <div class="container1" id="item">
                <input type="hidden" name="arrayP[Antipasti][<?php echo $i;?>][Nome]" value="<?php echo $nomePiatto;?>">
                  
                <p id="food"><?php echo $array['Antipasti'][$i]['nome'];?></p>
                <button type="button" class="btn decrement-btn" data-product-id="<?php echo $i; ?>">-</button>
                <span id="quantity-<?php echo $j; ?>" class="quantity">0</span>
                <button type="button" class="btn increment-btn" data-product-id="<?php echo $j; ?>">+</button>

                <input type="hidden" name='arrayP[Antipasti][<?php echo $i; ?>][Quantita]' id="quantityInput-<?php echo $j; ?>" value="0">
                <?php
                if (!empty($array['Antipasti'][$i]['aggiunte'])) {
                    $array_aggiunte = explode("-", $array['Antipasti'][$i]['aggiunte']);
                    //echo "<form>";
                    echo "<div class='conta'>";
                    echo "<label for='dropdown-trigger-$i' id='option-label-$i' class='option-label' onclick='toggleOptions($i)'>Aggiunte</label>";
                    echo "</div>";
                    echo "<div id='dropdown-$i' class='options dropdown'>";

                    // Stampare le opzioni recuperate dal database nel menu a tendina
                    for ($g = 0; $g < count($array_aggiunte); $g++) {
                        echo "<label><input type='checkbox' name='arrayP[Antipasti][$i][Aggiunte][]' class='option-checkbox' value='" . htmlspecialchars($array_aggiunte[$g]) . "'>" . htmlspecialchars($array_aggiunte[$g]) . "</label>";
                    }
                    echo "</div>";
                    //echo "</form>";

                } else {
                    //echo "Nessuna opzione disponibile nel database.";
                }
                  echo "<textarea id=" . $array['Antipasti'][$i]['nome'] ." name='arrayP[Antipasti][$i][Descrizione]' placeholder='Clicca qui per scrivere' onclick='espandiTextarea(this)'></textarea> ";
                 $j++;
                 ?>   
            </div>
            <?php }?>
        </div>
            <?php }?>
          
        <!--PRIMI-->  
        <div class="category">
            <?php
            if (!empty($array['Primi'])) {
            ?> 
            <h2 id="primi">Primi</h2>
            <?php
                for ($i = 0; $i < count($array['Primi']); $i++) {
                $nomePiatto = $array['Primi'][$i]['nome'];
            ?>
            <div class="container1" id="item">
                <input type="hidden" name="arrayP[Primi][<?php echo $i;?>][Nome]" value="<?php echo $nomePiatto;?>">
                  
                <p id="food"><?php echo $array['Primi'][$i]['nome'];?></p>
                <button type="button" class="btn decrement-btn" data-product-id="<?php echo $j; ?>">-</button>
                <span id="quantity-<?php echo $j; ?>" class="quantity">0</span>
                
                <button type="button" class="btn increment-btn" data-product-id="<?php echo $j; ?>">+</button>

                <input type="hidden" name='arrayP[Primi][<?php echo $i; ?>][Quantita]' id="quantityInput-<?php echo $j; ?>" value="0">
                <?php
                if (!empty($array['Primi'][$i]['aggiunte'])) {
                    $array_aggiunte = explode("-", $array['Primi'][$i]['aggiunte']);
                    //echo "<form>";
                    echo "<div class='conta'>";
                    echo "<label for='dropdown-trigger-$i' id='option-label-$i' class='option-label' onclick='toggleOptions($i)'>Aggiunte</label>";
                    echo "</div>";
                    echo "<div id='dropdown-$i' class='options dropdown'>";

                    // Stampare le opzioni recuperate dal database nel menu a tendina
                    for ($g = 0; $g < count($array_aggiunte); $g++) {
                        echo "<label><input type='checkbox' name='arrayP[Primi][$i][Aggiunte][]' class='option-checkbox' value='" . htmlspecialchars($array_aggiunte[$g]) . "'>" . htmlspecialchars($array_aggiunte[$g]) . "</label>";
                    }
                    echo "</div>";
                    //echo "</form>";

                } else {
                    //echo "Nessuna opzione disponibile nel database.";
                }
                  echo "<textarea id=" . $array['Primi'][$i]['nome'] ." name='arrayP[Primi][$i][Descrizione]' placeholder='Clicca qui per scrivere' onclick='espandiTextarea(this)'></textarea> ";
                  $j++;
                 ?>   
            </div>
            <?php }?>
        </div>
            <?php }?>
          <!--SECONDI-->  
          <div class="category">
            <?php
            if (!empty($array['Secondi'])) {
            ?> 
            <h2 id="secondi">Secondi</h2>
            <?php
                for ($i = 0; $i < count($array['Secondi']); $i++) {
                $nomePiatto = $array['Secondi'][$i]['nome'];
            ?>
            <div class="container1" id="item">
                <input type="hidden" name="arrayP[Secondi][<?php echo $i;?>][Nome]" value="<?php echo $nomePiatto;?>">
                  
                <p id="food"><?php echo $array['Secondi'][$i]['nome'];?></p>
                <button type="button" class="btn decrement-btn" data-product-id="<?php echo $j; ?>">-</button>
                
                <span id="quantity-<?php echo $j; ?>" class="quantity">0</span>
                <button type="button" class="btn increment-btn" data-product-id="<?php echo $j; ?>">+</button>

                <input type="hidden" name='arrayP[Secondi][<?php echo $i; ?>][Quantita]' id="quantityInput-<?php echo $j; ?>" value="0">
                <?php
                if (!empty($array['Secondi'][$i]['aggiunte'])) {
                    $array_aggiunte = explode("-", $array['Secondi'][$i]['aggiunte']);
                    //echo "<form>";
                    echo "<div class='conta'>";
                    echo "<label for='dropdown-trigger-$i' id='option-label-$i' class='option-label' onclick='toggleOptions($i)'>Aggiunte</label>";
                    echo "</div>";
                    echo "<div id='dropdown-$i' class='options dropdown'>";

                    // Stampare le opzioni recuperate dal database nel menu a tendina
                    for ($g = 0; $g < count($array_aggiunte); $g++) {
                        echo "<label><input type='checkbox' name='arrayP[Secondi][$i][Aggiunte][]' class='option-checkbox' value='" . htmlspecialchars($array_aggiunte[$g]) . "'>" . htmlspecialchars($array_aggiunte[$g]) . "</label>";
                    }
                    echo "</div>";
                    //echo "</form>";

                } else {
                    //echo "Nessuna opzione disponibile nel database.";
                }
                  echo "<textarea id=" . $array['Secondi'][$i]['nome'] ." name='arrayP[Secondi][$i][Descrizione]' placeholder='Clicca qui per scrivere' onclick='espandiTextarea(this)'></textarea> ";
                  $j++;
                 ?>   
            </div>
            <?php }?>
        </div>
            <?php }?>
          <!--DOLCI-->
          <div class="category">
            <?php
            if (!empty($array['Dolci'])) {
            ?> 
            <h2 id="dolci">Dolci</h2>
            <?php
                for ($i = 0; $i < count($array['Dolci']); $i++) {
                $nomePiatto = $array['Dolci'][$i]['nome'];
            ?>
            <div class="container1" id="item">
                <input type="hidden" name="arrayP[Dolci][<?php echo $i;?>][Nome]" value="<?php echo $nomePiatto;?>">
                  
                <p id="food"><?php echo $array['Dolci'][$i]['nome'];?></p>
                <button type="button" class="btn decrement-btn" data-product-id="<?php echo $j; ?>">-</button>
                <span id="quantity-<?php echo $j; ?>" class="quantity">0</span>
                
                <button type="button" class="btn increment-btn" data-product-id="<?php echo $j; ?>">+</button>

                <input type="hidden" name='arrayP[Dolci][<?php echo $i; ?>][Quantita]' id="quantityInput-<?php echo $j; ?>" value="0">
                <?php
                if (!empty($array['Dolci'][$i]['aggiunte'])) {
                    $array_aggiunte = explode("-", $array['Dolci'][$i]['aggiunte']);
                    //echo "<form>";
                    echo "<div class='conta'>";
                    echo "<label for='dropdown-trigger-$i' id='option-label-$i' class='option-label' onclick='toggleOptions($i)'>Aggiunte</label>";
                    echo "</div>";
                    echo "<div id='dropdown-$i' class='options dropdown'>";

                    // Stampare le opzioni recuperate dal database nel menu a tendina
                    for ($g = 0; $g < count($array_aggiunte); $g++) {
                        echo "<label><input type='checkbox' name='arrayP[Dolci][$i][Aggiunte][]' class='option-checkbox' value='" . htmlspecialchars($array_aggiunte[$g]) . "'>" . htmlspecialchars($array_aggiunte[$g]) . "</label>";
                    }
                    echo "</div>";
                    //echo "</form>";

                } else {
                    //echo "Nessuna opzione disponibile nel database.";
                }
                  echo "<textarea id=" . $array['Dolci'][$i]['nome'] ." name='arrayP[Dolci][$i][Descrizione]' placeholder='Clicca qui per scrivere' onclick='espandiTextarea(this)'></textarea> ";
                  $j++;
                 ?>   
            </div>
            <?php }?>
        </div>
            <?php }?>
          <!--BIBITE-->
          <div class="category">
            <?php
            if (!empty($array['Bibite'])) {
            ?> 
            <h2 id="bibite">Bibite</h2>
            <?php
                for ($i = 0; $i < count($array['Bibite']); $i++) {
                $nomePiatto = $array['Bibite'][$i]['nome'];
            ?>
            <div class="container1" id="item">
                <input type="hidden" name="arrayP[Bibite][<?php echo $i;?>][Nome]" value="<?php echo $nomePiatto;?>">
                  
                <p id="food"><?php echo $array['Bibite'][$i]['nome'];?></p>
                <button type="button" class="btn decrement-btn" data-product-id="<?php echo $j; ?>">-</button>
                <span id="quantity-<?php echo $j; ?>" class="quantity">0</span>
                
                <button type="button" class="btn increment-btn" data-product-id="<?php echo $j; ?>">+</button>

                <input type="hidden" name='arrayP[Bibite][<?php echo $i; ?>][Quantita]' id="quantityInput-<?php echo $j; ?>" value="0">
                <?php
                if (!empty($array['Bibite'][$i]['aggiunte'])) {
                    $array_aggiunte = explode("-", $array['Bibite'][$i]['aggiunte']);
                    //echo "<form>";
                    echo "<div class='conta'>";
                    echo "<label for='dropdown-trigger-$i' id='option-label-$i' class='option-label' onclick='toggleOptions($i)'>Aggiunte</label>";
                    echo "</div>";
                    echo "<div id='dropdown-$i' class='options dropdown'>";

                    // Stampare le opzioni recuperate dal database nel menu a tendina
                    for ($g = 0; $g < count($array_aggiunte); $g++) {
                        echo "<label><input type='checkbox' name='arrayP[Bibite][$i][Aggiunte][]' class='option-checkbox' value='" . htmlspecialchars($array_aggiunte[$g]) . "'>" . htmlspecialchars($array_aggiunte[$g]) . "</label>";
                    }
                    echo "</div>";
                    //echo "</form>";

                } else {
                    //echo "Nessuna opzione disponibile nel database.";
                }
                  echo "<textarea id=" . $array['Bibite'][$i]['nome'] ." name='arrayP[Bibite][$i][Descrizione]' placeholder='Clicca qui per scrivere' onclick='espandiTextarea(this)'></textarea> ";
                  $j++;
                 ?>   
            </div>
            <?php }?>
        </div>
            <?php }?>
          <!--VINI-->
          <div class="category">
            <?php
            if (!empty($array['Vini'])) {
            ?> 
            <h2 id="vini">Vini</h2>
            <?php
                for ($i = 0; $i < count($array['Vini']); $i++) {
                $nomePiatto = $array['Vini'][$i]['nome'];
            ?>
            <div class="container1" id="item">
                <input type="hidden" name="arrayP[Vini][<?php echo $i;?>][Nome]" value="<?php echo $nomePiatto;?>">
                  
                <p id="food"><?php echo $array['Vini'][$i]['nome'];?></p>
                <button type="button" class="btn decrement-btn" data-product-id="<?php echo $j; ?>">-</button>
                
                <span id="quantity-<?php echo $j; ?>" class="quantity">0</span>
                <button type="button" class="btn increment-btn" data-product-id="<?php echo $j; ?>">+</button>

                <input type="hidden" name='arrayP[Vini][<?php echo $i; ?>][Quantita]' id="quantityInput-<?php echo $j; ?>" value="0">
                <?php
                if (!empty($array['Vini'][$i]['aggiunte'])) {
                    $array_aggiunte = explode("-", $array['Vini'][$i]['aggiunte']);
                    //echo "<form>";
                    echo "<div class='conta'>";
                    echo "<label for='dropdown-trigger-$i' id='option-label-$i' class='option-label' onclick='toggleOptions($i)'>Aggiunte</label>";
                    echo "</div>";
                    echo "<div id='dropdown-$i' class='options dropdown'>";

                    // Stampare le opzioni recuperate dal database nel menu a tendina
                    for ($g = 0; $g < count($array_aggiunte); $g++) {
                        echo "<label><input type='checkbox' name='arrayP[Vini][$i][Aggiunte][]' class='option-checkbox' value='" . htmlspecialchars($array_aggiunte[$g]) . "'>" . htmlspecialchars($array_aggiunte[$g]) . "</label>";
                    }
                    echo "</div>";
                    //echo "</form>";

                } else {
                    //echo "Nessuna opzione disponibile nel database.";
                }
                  echo "<textarea id=" . $array['Vini'][$i]['nome'] ." name='arrayP[Vini][$i][Descrizione]' placeholder='Clicca qui per scrivere' onclick='espandiTextarea(this)'></textarea> ";
                  $j++;
                 ?>   
            </div>
            <?php }?>
        </div>
            <?php }?>
        <button class="texture" type="submit" value="Submit">Invio</button>
      </form>

    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
       function openNav() {
            if (window.innerWidth > 600) { // se la larghezza dello schermo è maggiore di 600px
                document.getElementById("mySidebar").style.width = "20%";
            } else {
                document.getElementById("mySidebar").style.width = "75%";
            }
        }

        function closeNav() {
            document.getElementById("mySidebar").style.width = "0";
        }

        /*numero portata*/
        // Incrementa la quantità quando si clicca sul pulsante "+"
    $('.increment-btn').click(function() {
        var productId = $(this).data('product-id');
        var quantityInput = $('#quantityInput-' + productId);
        var quantity = parseInt(quantityInput.val()) || 0;
        quantity++;
        quantityInput.val(quantity);
        $('#quantity-' + productId).text(quantity);
    });

    // Decrementa la quantità quando si clicca sul pulsante "-"
    $('.decrement-btn').click(function() {
        var productId = $(this).data('product-id');
        var quantityInput = $('#quantityInput-' + productId);
        var quantity = parseInt(quantityInput.val()) || 0;
        if (quantity > 0) {
            quantity--;
            quantityInput.val(quantity);
            $('#quantity-' + productId).text(quantity);
        }
    });

// Aggiorna la funzione updateQuantity per accettare la nuova quantità come argomento
function updateQuantity(productId, quantity) {
    $('#quantity-' + productId).text(quantity);
    $('#quantityInput-' + productId).val(quantity); // Aggiorna il valore nell'input nascosto
}






        /*menu a tendina aggiunte*/
        function toggleOptions(index) {
        const options = document.getElementById('dropdown-' + index);
        const label = document.getElementById('option-label-' + index);
        if (options.style.display === 'none' || options.style.display === '') {
            options.style.display = 'block';
            label.style.display = 'none'; // Nascondi il testo dell'etichetta
        } else {
            options.style.display = 'none';
            label.style.display = 'block'; // Riapparire il testo dell'etichetta
        }
    }

    /*textarea*/
     // Funzione per gestire il clic sulla textarea
    function espandiTextarea(textarea) {
      textarea.classList.add("expanded");
      textarea.focus(); // Imposta il focus sulla textarea ingrandita
      textarea.style.zIndex = "9999"; // Imposta il valore di z-index sopra a tutti gli altri elementi
    }

    // Funzione per gestire l'uscita dalla textarea
    function rimpicciolisciTextarea(textarea) {
      textarea.classList.remove("expanded");
    }

    // Aggiunta di un listener per l'uscita dalla textarea
    document.addEventListener("focusout", function(event) {
      if (event.target.tagName === "TEXTAREA") {
        rimpicciolisciTextarea(event.target);
      }
    });

    // Aggiunta di un listener per il clic sulla textarea
    document.addEventListener("click", function(event) {
      if (event.target.tagName === "TEXTAREA") {
        espandiTextarea(event.target);
      }
    });
    
    </script>
  </body>
</html>


