<?php
require 'developers_conferma.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Conferma ordini</title>
    <style>
        body {
            font-family: Arial, sans-serif !important;
            margin: 0;
            padding: 0;
        }

        header {
            text-align: center;
            background-color: #c6a664;
        }

        #center {
            text-align: center;
            background-color: yellow;
        }

        .vetrina {
            display: flex;
            flex-wrap: wrap;
        }

        .scontrino {
            margin-bottom: 10px;
            width: 300px; /* Larghezza fissa degli scontrini */
            margin-left: 5px;
            margin-right: 5px;
            background-color: #ccc; /* Solo per chiarezza visiva */
            flex: 1 0 auto; /* Flessibilità per adattarsi al contenitore */
        }

        .cliccabile {
            padding-left: 10px;
            padding-top: 10px;
            background-color: lightblue;
            margin: auto;
            cursor: pointer;
        }

        .selezionato {
            background-color: lightgreen; /* Cambia il colore quando selezionato */
        }

        .disabled {
            opacity: 0.5; /* Opacità ridotta per indicare lo stato disabilitato */
            pointer-events: none; /* Impedisce l'interazione con il div */
            
        }
        .pronto {
            background-color: red;
            pointer-events: none; /* Impedisce l'interazione con il div */
            
        }

        @media screen and (max-height: 500px) {
            .scontrino {
            }
        }
    </style>
</head>
<body>

<?php
$find = false;
if(is_array($fetchData)){      
    // Array per raggruppare i dati per categoria e tipo
    $raggruppatoPerCategoriaTipo = array();

    // Ciclo attraverso i dati della tabella
    foreach ($fetchData as $riga) {
        $categoria = $riga['tavolo'];
        $tipo = $riga['sezione'];

        // Verifica se la categoria è già presente nell'array raggruppato
        if (!isset($raggruppatoPerCategoriaTipo[$categoria])) {
            // Se la categoria non è presente, aggiungila con un array vuoto
            $raggruppatoPerCategoriaTipo[$categoria] = array();
        }

        // Verifica se il tipo è già presente nell'array raggruppato per questa categoria
        if (!isset($raggruppatoPerCategoriaTipo[$categoria][$tipo])) {
            // Se il tipo non è presente, aggiungilo con un array vuoto
            $raggruppatoPerCategoriaTipo[$categoria][$tipo] = array();
        }

        // Aggiungi la riga corrente all'array del tipo all'interno della categoria
        $raggruppatoPerCategoriaTipo[$categoria][$tipo][] = $riga;
    }

    // Definisci l'ordine desiderato per le chiavi
    $ordineChiavi = array(
        'Antipasti',
        'Primi',
        'Secondi',
        'Dolci',
        'Bibite',
        'Vini'
    );

    // Ordina le chiavi all'interno di ciascun tavolo secondo l'ordine specificato
    foreach ($raggruppatoPerCategoriaTipo as &$tavolo) {
        uksort($tavolo, function ($a, $b) use ($ordineChiavi) {
            return array_search($a, $ordineChiavi) - array_search($b, $ordineChiavi);
        });
    }
    /*echo "<pre>";
    print_r($raggruppatoPerCategoriaTipo);
    echo "</pre>";*/
    ?>
    <?php
    $find = true;
} else {
    $find = false;
}
?> 
<header>
    <h1>Conferma ordini</h1>
</header>
<?php
if ($find == false) {
    echo "No data found";
} else {


?>
<main>
    <div class="vetrina">
        <?php
        $i = 0;
        foreach ($raggruppatoPerCategoriaTipo as $chiave => $data) {
            ?>
            <div class="scontrino">
                <h2 id="center"><?php echo $chiave; ?></h2>
                <?php
                
                foreach ($data as $key => $valore) {
                    ?>
                    <h3 id="center"><?php echo $key; ?></h3>
                    <?php
                    foreach ($valore as $llave => $valor) {
                        if ($valor['stato'] == 'Inviato') {
                            $stato = "disabled";
                        } elseif ($valor['stato'] == 'Pronto')  {
                            $stato = "pronto";
                        } else {
                            $stato = "cliccabile";
                        }
                        ?>
                        <div class='<?php echo $stato; ?>' id='<?php echo $valor['id']; ?>'>
                            <?php
                            foreach ($valor as $llav => $val) {
                                echo $llav . ": ";
                                print_r($val);
                                echo "<br />";

                            }
                            echo "<br />";
                            $i++;
                            ?>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>
    <form id="myForm" action="ricezione_conferma.php" method="post">
        <input type="hidden" id="divIdInput" name="divId">
    </form>
    <button id="submitBtn">Invia Dati in cucina</button>
    <form id="myForm" action="ricezione_conferma.php" method="post">
        <input type="number" name="tavoloId">
        <button id="submitBtn">Chiusura tavolo</button>
    </form>
    
    <a href="invio.php">Indietro</a>
<?php
}
?>
    

    <script>
        // Funzione per gestire il clic su un div
        function gestisciClic() {
            this.classList.toggle('selezionato');
        }

        // Aggiungi gestore di eventi clic a ciascun div
        const divs = document.querySelectorAll('.cliccabile');
        divs.forEach(div => {
            div.addEventListener('click', gestisciClic);
        });

        // Funzione per inviare i dati a PHP tramite il modulo HTML
        document.getElementById('submitBtn').addEventListener('click', function() {
            const selectedDiv = document.querySelector('.selezionato');

            if (selectedDiv) {
                const divId = selectedDiv.id;
                const divIdInput = document.getElementById('divIdInput');
                divIdInput.value = divId;
                // Disabilita i div cliccabili per evitare ulteriori clic
                divs.forEach(div => {
                    div.classList.add('disabled');
                });
                // Simula il submit del modulo
                document.getElementById('myForm').submit();
            } else {
                alert('Nessun div selezionato.');
            }
        });

        
    </script>
</main>
</body>
</html>
