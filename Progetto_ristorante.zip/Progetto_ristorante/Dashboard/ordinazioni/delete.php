<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || (getUserEmail() != "Capo" && getUserEmail() != "Cameriere1" && getUserEmail() != "Cameriere2")) {
   header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<?php
// Controlla se è stato ricevuto un ID dall'oggetto o dallo scontrino da eliminare
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Query per eliminare l'oggetto o lo scontrino dal database
    // Modifica questa query in base alla tua struttura del database
    $sql = "DELETE FROM nome_tabella WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "Record eliminato con successo";
    } else {
        echo "Errore durante l'eliminazione del record: " . $conn->error;
    }
} else {
    echo "ID non ricevuto";
}

// Chiudi la connessione
$conn->close();
?>
