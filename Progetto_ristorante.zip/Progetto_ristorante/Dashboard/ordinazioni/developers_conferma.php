<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() ||(getUserEmail() != "Capo" && getUserEmail() != "Cameriere1" && getUserEmail() != "Cameriere2")) {
   header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<?php
$db = $conn;
$tableName = "conferma";
$columns = ['id', 'tavolo','date', 'codPiatto', 'aggiunte', 'quantita', 'descrizione', 'stato', 'pagato', 'codCameriere'];

$fetchData = fetch_data($db, $tableName, $columns);

function fetch_data ($db, $tableName, $columns) {
 if(empty($db)){
  $msg = "Database connection error";
 }elseif (empty($columns) || !is_array($columns)) {
  $msg = "columns Name must be defined in an indexed array";
 }elseif(empty($tableName)){
   $msg = "Table Name is empty";
}else{
$columnName = implode(", ", $columns);
$query = "SELECT menu.sezione, menu.nome, conferma.id, conferma.tavolo, conferma.date, conferma.aggiunte, conferma.quantita, conferma.descrizione, conferma.stato, conferma.pagato, account.username AS nome_cameriere FROM menu INNER JOIN conferma ON conferma.codPiatto = menu.id INNER JOIN account ON conferma.codCameriere = account.id  WHERE pagato <> 'Si'";

$result = $db->query($query);

if($result == true){ 
 if ($result->num_rows > 0) {
    $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    $msg= $row;
 } else {
    $msg= "No Data Found"; 
 }
}else{
  $msg= mysqli_error($db);
}
}
return $msg;
}
?>