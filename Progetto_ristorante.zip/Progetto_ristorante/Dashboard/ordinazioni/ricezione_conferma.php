<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || (getUserEmail() != "Capo" && getUserEmail() != "Cameriere1" && getUserEmail() != "Cameriere2" && getUserEmail() != "Cameriere3")) {
   header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<?php
// Controlla se è stata inviata una richiesta POST

    // Controlla se il campo 'divId' è stato inviato nel modulo
   
        // Leggi l'ID del div inviato dal modulo
        
        
        if (!empty($_POST['tavoloId'])) {
            $tavolo = mysqli_real_escape_string($conn, $_POST['tavoloId']);
            $i = 0;
            $sql2 = "SELECT tavolo, stato, num, id FROM conferma WHERE tavolo = $tavolo";
            $result2 = mysqli_query($conn, $sql2);
            // Verifica se ci sono risultati
            if (mysqli_num_rows($result2) > 0) {
                // Output dei dati
                while($row2 = mysqli_fetch_assoc($result2)) {
                    if ($row2["tavolo"] == $tavolo) {
                        if ($row2["stato"] == "Pronto") {
                            $arr[$i] = "1";
                        } else {
                            $arr[$i] = "0";
                        } 
                    } 
                    $i++;
                }
            
               //print_r($arr);
            $sql1 = "SELECT tavolo, pagato, id FROM conferma WHERE tavolo = $tavolo";
            $result1 = mysqli_query($conn, $sql1);
            // Verifica se ci sono risultati
            if (mysqli_num_rows($result1) > 0) {
                // Output dei dati
                if (in_array(0, $arr)) {
                    echo "non tutti i piatti sono stati confermati";
                } else {
                    while($row = mysqli_fetch_assoc($result1)) {
                        if ($row["tavolo"] == $tavolo && $row["pagato"] == "No") {
                            $id = $row['id'];
                           $sql = "UPDATE conferma SET pagato = 'Si' WHERE id = $id";
                           if ($conn->query($sql) === TRUE) {
                               echo "Dati aggiornati correttamente";
                           } else {
                               echo "Errore nell'aggiornamento dei dati: " . $conn->error;
                           }
                        }
                    }
                }
            } else {
                //inviare messaggio che non esiste
                echo "tavolo non esiste";
            }
            } else {
                echo "tavolo non esiste";
            }
        } else {

        }
        if (!empty($_POST['divId'])) {

        $id = $_POST['divId'];
        $parola_da_cercare = "div-";

        if (strpos($_POST['divId'], $parola_da_cercare) !== false) {
            
            $tmp = explode("-", $id);
            $id = $tmp[1];
            echo "ID del div selezionato: " . htmlspecialchars($id);
            // Fai qualcosa con l'ID del div, come ad esempio salvare i dati nel database o elaborarli in qualche modo

            $nuovo_valore = "Pronto";

            // Query di aggiornamento
            $sql = "UPDATE conferma SET stato = '$nuovo_valore' WHERE id = $id";

            if ($conn->query($sql) === TRUE) {
                echo "Dati aggiornati correttamente";
                header('Location:monitor.php');
                die;
            } else {
                echo "Errore nell'aggiornamento dei dati: " . $conn->error;
            }
        } else {
            echo "ID del div selezionato: " . htmlspecialchars($id);
            // Fai qualcosa con l'ID del div, come ad esempio salvare i dati nel database o elaborarli in qualche modo

            $nuovo_valore = "Inviato";

            // Query di aggiornamento
            $sql = "UPDATE conferma SET stato = '$nuovo_valore' WHERE id = $id";

            if ($conn->query($sql) === TRUE) {
                echo "Dati aggiornati correttamente";
                header('Location:conferma.php');
                die;
            } else {
                echo "Errore nell'aggiornamento dei dati: " . $conn->error;
            }
        }
    }
        header('Location:conferma.php');
        die;

?>