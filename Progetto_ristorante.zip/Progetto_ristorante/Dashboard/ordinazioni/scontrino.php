<?php
session_start();
require '../../functions.php';
require '../../connection.php';

// Check if user is logged in and authorized
if (!isUserLoggedIn() || !in_array(getUserEmail(), ["Capo", "Cameriere1", "Cameriere2", "Cameriere3"])) {
    header('Location:../../login.php');
    die();
}

// CSS for styling the receipt
echo '
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f8f8f8;
        padding: 20px;
    }
    .receipt-container {
        max-width: 600px;
        margin: auto;
        background-color: #fff;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .receipt-header {
        text-align: center;
        margin-bottom: 20px;
    }
    .receipt-header h1 {
        margin: 0;
        font-size: 24px;
    }
    .table-number {
        text-align: center;
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 5px;
    }
    .covers-number {
        text-align: center;
        font-size: 18px;
        margin-bottom: 20px;
    }
    .receipt-item {
        border-bottom: 1px solid #eee;
        padding: 10px 0;
    }
    .receipt-item:last-child {
        border-bottom: none;
    }
    .receipt-item span {
        display: block;
    }
    .receipt-item .item-title {
        font-weight: bold;
    }
    .receipt-total {
        font-size: 20px;
        font-weight: bold;
        text-align: right;
        margin-top: 20px;
    }
</style>
';

echo '<div class="receipt-container">';
echo '<div class="receipt-header"><h1>Scontrino</h1></div>';

if (isset($_SESSION['scontrino_data'])) {
    $scontrino_data = $_SESSION['scontrino_data'];
    unset($_SESSION['scontrino_data']); // Clear the session data after use

    $total_cost = 0;
    $table_number = htmlspecialchars($scontrino_data[0]['tavolo']);
    $covers_number = htmlspecialchars($scontrino_data[0]['coperti']);

    // Display table number and covers only once
    echo '<div class="table-number">Tavolo: ' . $table_number . '</div>';
    echo '<div class="covers-number">Coperti: ' . $covers_number . '</div>';

    // Process the data as needed
    foreach ($scontrino_data as $row) {
        $cost = htmlspecialchars($row['prezzo']) * htmlspecialchars($row['quantita']);
        $total_cost += $cost;

        echo '<div class="receipt-item">';
        echo '<span>Date: ' . htmlspecialchars($row['date']) . '</span>';
        echo '<span>Sezione: ' . htmlspecialchars($row['sezione']) . '</span>';
        echo '<span>Piatto: ' . htmlspecialchars($row['nome']) . '</span>';
        echo '<span>Aggiunte: ' . htmlspecialchars($row['aggiunte']) . '</span>';
        echo '<span>Quantita: ' . htmlspecialchars($row['quantita']) . '</span>';
        echo '<span>Costo: €' . number_format($cost, 2) . '</span>';
        echo '</div>';
    }

    echo '<div class="receipt-total">Totale: €' . number_format($total_cost, 2) . '</div>';
} else {
    echo '<div class="receipt-item">Nessun dato disponibile.</div>';
}

echo '</div>';
?>
