<?php
session_start();
require 'functions.php';
require 'connection.php';
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Login</title>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
<style>
section{
    background-color: #333 !important;
    color: #fff !important;
    text-shadow: 0 .05rem .1rem rgba(255, 255, 255, .5) !important;
}
#responsive-image {
    display: none;
}

/* Media query per schermi con larghezza massima di 768px */
@media (max-width: 768px) {
    /* Mostra l'immagine solo quando la larghezza è inferiore a 768px */
    #responsive-image {
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
    .login-form {
        margin-top: 20px; /* Aggiungi margine sopra al modulo di login */
    }
}
</style>
</head>
<main role="main" class="text-center">
  
<section class="vh-100" style="background-color:  black;"  >

  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      
      <div class="col col-xl-10">
        <div class="card login-form" style="border-radius: 1rem;">
          <div class="row g-0">
            <div class="col-md-6 col-lg-5 d-none d-md-flex justify-content-center align-items-center">
              <img src="logo.png"
                alt="login form" class="img-fluid" style="border-radius: 1rem 0 0 1rem;" />
            </div>
            <div class="col-md-6 col-lg-7 d-flex align-items-center">
            <div class="card-body p-4 p-lg-5 text-black">
            <?php
            /*if (!empty($_SESSION['errors'])) { ?>
                <div class="alert alert-danger"><?= $_SESSION['errors'] ?></div>
            <?php
                $_SESSION['errors'] = '';
            }
            ?>
            <?php
           /* if (!empty($_SESSION['errors1'])) { ?>
                <div class="alert alert-danger"><?= $_SESSION['errors1'] ?></div>
            <?php
                $_SESSION['errors1'] = '';
            }*/
            ?>
            
          
            
            <form action="loginuser.php" method="POST" id="prova">
              <h1 class="cover-heading text-center">LOGIN</h1>
                <div class="form-group">
                    <label for="email">Username</label>
                    <input placeholder="username" type="username" class="form-control" id="email" name="email" aria-describedby="emailHelp">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input placeholder="password" type="password" id="password" name="password" class="form-control" id="exampleInputPassword1">
                </div>
                <button type="submit" class="btn btn-light">LOGIN</button>
            </form>
</div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</main>
</html>

    

<!--
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    
    <style>
        /*.bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }*/
        body { 
            display: -ms-flexbox;
            display: flex;
            color: #fff;
            text-shadow: 0 .05rem .1rem rgba(0, 0, 0, .5);
        }
    </style>
</head>
<body class="text-center" >
<?php
   // $page = $_SERVER['SCRIPT_NAME'];
    ?>
    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">

        <header class="masthead mb-auto">
        </header>
        <main role="main" class="inner cover">
            <h1 class="cover-heading">LOGIN</h1>
            <?php
           /* if (!empty($_SESSION['errors'])) { ?>
                <div class="alert alert-danger"><?= $_SESSION['errors'] ?></div>
            <?php
                $_SESSION['errors'] = '';
            }*/
            ?>
            <?php
            /*if (!empty($_SESSION['errors1'])) { ?>
                <div class="alert alert-danger"><?= $_SESSION['errors1'] ?></div>
            <?php
                $_SESSION['errors1'] = '';
            }*/
            ?>
            <form action="loginuser.php" method="POST" id="prova">
                <div class="form-group">
                    <label for="email">Username</label>
                    <input placeholder="username" type="username" class="form-control" id="email" name="email" aria-describedby="emailHelp">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input placeholder="password" type="password" id="password" name="password" class="form-control" id="exampleInputPassword1">
                </div>
                <button type="submit" class="btn btn-light">LOGIN</button>
            </form>
        </main>
        <footer class="mastfoot mt-auto">
            
        </footer>
    </div>
</body>
</html>
        -->