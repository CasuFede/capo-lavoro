<?php

function isUserLoggedIn()
{
    return $_SESSION['user_email'] ?? '';
}

function logout()
{
    session_destroy();
    return $_SESSION['user_email']  ?? '';
}
function getUserEmail()
{

    return $_SESSION['user_email'] ?? '';
}

function getUserId()
{
    return $_SESSION['user_id'] ?? '';
}
/*function getUserDiary()
{
    $diary = '';
    $sql = 'SELECT * from account where username=?';
    $stm = $GLOBALS['conn']->prepare($sql);
    if (!$stm) {
        die($GLOBALS['conn']->error);
    }
    $email = getUserEmail();
    $stm->bind_param('s', $email);
    $stm->bind_result($diary);
    $stm->execute();
    $stm->fetch();
    return $diary;
}*/
